import{a as e}from"./entry.52b0ebb0.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
