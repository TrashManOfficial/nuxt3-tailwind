const client_manifest = {
  "CustomTabs.css": {
    "resourceType": "style",
    "file": "CustomTabs.0840a874.css",
    "src": "CustomTabs.css"
  },
  "_CustomTabs.cced3cb5.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.65bd217b.png",
      "miniLogo.ebb38594.png",
      "aboutRight.bc772ea4.png",
      "douyin_qrcode.f1de708c.png",
      "ios.93d30a48.png",
      "logo_m.9890f935.png",
      "search.d2616e1f.png",
      "sina_qrcode.01b3299c.png",
      "statement.ceb6ff19.png",
      "usMsg.d1f0abb5.png",
      "wx_qrcode.877caabf.png",
      "ygaba.5c590e6b.png"
    ],
    "css": [
      "CustomTabs.0840a874.css"
    ],
    "file": "CustomTabs.cced3cb5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "CustomTabs.0840a874.css": {
    "file": "CustomTabs.0840a874.css",
    "resourceType": "style"
  },
  "logo.65bd217b.png": {
    "file": "logo.65bd217b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "miniLogo.ebb38594.png": {
    "file": "miniLogo.ebb38594.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "aboutRight.bc772ea4.png": {
    "file": "aboutRight.bc772ea4.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "douyin_qrcode.f1de708c.png": {
    "file": "douyin_qrcode.f1de708c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "ios.93d30a48.png": {
    "file": "ios.93d30a48.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "logo_m.9890f935.png": {
    "file": "logo_m.9890f935.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "search.d2616e1f.png": {
    "file": "search.d2616e1f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "sina_qrcode.01b3299c.png": {
    "file": "sina_qrcode.01b3299c.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "statement.ceb6ff19.png": {
    "file": "statement.ceb6ff19.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "usMsg.d1f0abb5.png": {
    "file": "usMsg.d1f0abb5.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "wx_qrcode.877caabf.png": {
    "file": "wx_qrcode.877caabf.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "ygaba.5c590e6b.png": {
    "file": "ygaba.5c590e6b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "_DropDownModal.85619206.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo_m.9890f935.png",
      "ios.93d30a48.png"
    ],
    "file": "DropDownModal.85619206.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_CustomTabs.cced3cb5.js"
    ]
  },
  "_SearchBar.b04ef330.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "search.d2616e1f.png"
    ],
    "file": "SearchBar.b04ef330.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_SideBar.03c12316.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "ygaba.5c590e6b.png"
    ],
    "file": "SideBar.03c12316.js",
    "imports": [
      "_CustomTabs.cced3cb5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_client-only.d4156693.js": {
    "resourceType": "script",
    "module": true,
    "file": "client-only.d4156693.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "assets/images/about.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "about.b160abdb.jpg",
    "src": "assets/images/about.jpg"
  },
  "assets/images/aboutRight.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "aboutRight.bc772ea4.png",
    "src": "assets/images/aboutRight.png"
  },
  "assets/images/douyin_qrcode.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "douyin_qrcode.f1de708c.png",
    "src": "assets/images/douyin_qrcode.png"
  },
  "assets/images/ios.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "ios.93d30a48.png",
    "src": "assets/images/ios.png"
  },
  "assets/images/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.65bd217b.png",
    "src": "assets/images/logo.png"
  },
  "assets/images/logo_m.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_m.9890f935.png",
    "src": "assets/images/logo_m.png"
  },
  "assets/images/miniLogo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "miniLogo.ebb38594.png",
    "src": "assets/images/miniLogo.png"
  },
  "assets/images/search.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "search.d2616e1f.png",
    "src": "assets/images/search.png"
  },
  "assets/images/searchBg.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "searchBg.18e7c232.jpg",
    "src": "assets/images/searchBg.jpg"
  },
  "assets/images/sina_qrcode.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "sina_qrcode.01b3299c.png",
    "src": "assets/images/sina_qrcode.png"
  },
  "assets/images/statement.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "statement.ceb6ff19.png",
    "src": "assets/images/statement.png"
  },
  "assets/images/usMsg.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "usMsg.d1f0abb5.png",
    "src": "assets/images/usMsg.png"
  },
  "assets/images/wx_qrcode.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "wx_qrcode.877caabf.png",
    "src": "assets/images/wx_qrcode.png"
  },
  "assets/images/ygaba.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "ygaba.5c590e6b.png",
    "src": "assets/images/ygaba.png"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.2580a457.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.daebdcf3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.d9f2ae18.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "searchBg.18e7c232.jpg"
    ],
    "css": [
      "entry.d9f2ae18.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.52b0ebb0.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.d9f2ae18.css": {
    "file": "entry.d9f2ae18.css",
    "resourceType": "style"
  },
  "searchBg.18e7c232.jpg": {
    "file": "searchBg.18e7c232.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/about/index.css": {
    "resourceType": "style",
    "file": "index.7ede5eaa.css",
    "src": "pages/about/index.css"
  },
  "pages/about/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "about.b160abdb.jpg",
      "aboutRight.bc772ea4.png",
      "statement.ceb6ff19.png",
      "usMsg.d1f0abb5.png"
    ],
    "css": [],
    "file": "index.0454e4de.js",
    "imports": [
      "_CustomTabs.cced3cb5.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/about/index.vue"
  },
  "index.7ede5eaa.css": {
    "file": "index.7ede5eaa.css",
    "resourceType": "style"
  },
  "about.b160abdb.jpg": {
    "file": "about.b160abdb.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/detail/index.css": {
    "resourceType": "style",
    "file": "index.5ad72ab2.css",
    "src": "pages/detail/index.css"
  },
  "pages/detail/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.aaf3ece7.js",
    "imports": [
      "_client-only.d4156693.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_CustomTabs.cced3cb5.js",
      "_SideBar.03c12316.js",
      "_SearchBar.b04ef330.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/detail/index.vue"
  },
  "index.5ad72ab2.css": {
    "file": "index.5ad72ab2.css",
    "resourceType": "style"
  },
  "pages/home/index.css": {
    "resourceType": "style",
    "file": "index.3ba7f8fe.css",
    "src": "pages/home/index.css"
  },
  "pages/home/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.b6c83a50.js",
    "imports": [
      "_client-only.d4156693.js",
      "_CustomTabs.cced3cb5.js",
      "_DropDownModal.85619206.js",
      "_SideBar.03c12316.js",
      "_SearchBar.b04ef330.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/home/index.vue"
  },
  "index.3ba7f8fe.css": {
    "file": "index.3ba7f8fe.css",
    "resourceType": "style"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.a6e88544.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "pages/search/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.3f7a35db.js",
    "imports": [
      "_CustomTabs.cced3cb5.js",
      "_DropDownModal.85619206.js",
      "_SideBar.03c12316.js",
      "_SearchBar.b04ef330.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/search/index.vue"
  },
  "pages/special/index.css": {
    "resourceType": "style",
    "file": "index.7c958a45.css",
    "src": "pages/special/index.css"
  },
  "pages/special/index.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "index.ce62dd89.js",
    "imports": [
      "_CustomTabs.cced3cb5.js",
      "_SideBar.03c12316.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/special/index.vue"
  },
  "index.7c958a45.css": {
    "file": "index.7c958a45.css",
    "resourceType": "style"
  },
  "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.933d8e36.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
