const interopDefault = r => r.default || r || [];
const styles = {
  "pages/about/index.vue": () => import('./_nuxt/index-styles.5acdd38a.mjs').then(interopDefault),
  "pages/detail/index.vue": () => import('./_nuxt/index-styles.f9d67835.mjs').then(interopDefault),
  "pages/home/index.vue": () => import('./_nuxt/index-styles.56a85194.mjs').then(interopDefault),
  "pages/special/index.vue": () => import('./_nuxt/index-styles.304a1e00.mjs').then(interopDefault),
  "components/ListItem/Carousel.vue": () => import('./_nuxt/Carousel-styles.6b7eebb2.mjs').then(interopDefault),
  "components/ListItem/CarouselDetail.vue": () => import('./_nuxt/CarouselDetail-styles.e1a70dd0.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.a5c3f351.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.6b5b5ff2.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
