import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { ref, withAsyncContext, unref, useSSRContext } from 'vue';
import { ssrRenderClass, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { u as useBreakpoints, b as breakpointsTailwind, a as useElementVisibility, c as channelStore, _ as _imports_0$1, C as CustomTabs, d as _imports_2, S as ScrollToTop, F as Footer } from './CustomTabs-8591f744.mjs';
import { useRoute, useRouter } from 'vue-router';
import { _ as _export_sfc } from '../server.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-devtools-stub';
import 'axios';
import 'vue3-lazyload';

const _imports_1 = "" + buildAssetsURL("about.b160abdb.jpg");
const _imports_3 = "" + buildAssetsURL("aboutRight.bc772ea4.png");
const _imports_4 = "" + buildAssetsURL("statement.ceb6ff19.png");
const _imports_5 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAAA8CAYAAACEhkNqAAAKJ0lEQVR4nO1dO47jOBB909gLcI/gPoI7XwiwQ4XuI3SHE7bDCe1wQvsIdqiwBQibt46wOsLwCLsBq6wSTUrUz/YO+AChNbJEUuRjVbGqqPmGiCuorFA6TfQN61sAWNA/K50m1Rx1tJWrsmKl0yTvW+6PHz+c1//oW1AbqIM+ABx1mpQB97/BdGTvF5oCKisUgCUdfL4CcATwPkNdKzoWAF4FeTcAdnS+BbC3nh006OL5JYAvlRUlgLNOk734jeteqKxYTzUWf1Dhn0ML0GmypjKWAL7o8kplxUvbrKeO3gFQKis0gHUIGftCZcWKTpfirxJ/XXhTWQGdJqPIRXUzWVfWz58AXjqeXwI4AFiqrHjXaXIc2BTZB2frN41aWp5UVjzLcVNZ8W9bwT/dl3OWWPZL94ZOk1JlxR5GYi0AnACsWx55Qz2wZaCEY0IwFqIM+ZtULX1RASgBVH1UoiDRArUU7Hpm2fHeXCYAHOj+IWTfiPMGsXSa5CortqBJDkPk1wF1NMDEYvHHs1jDdK4NOXgl3ScbuZWzVGXFhxS7l0Jqlclo7SwS16f2V+mN3PpbhqoBav8GtVoLIbGmulgdddpROk32JM0PdKm3JCWpdxkzV71Uz4bu26is2Og0YQJuA6tawAgLAEQsoc4+YTqr5GtWI1cwIhwAtp6B2Ip7PlRWuDrxA7Wk2XZ1sk6TM3WwT3VJlGhKMm5TSWWNtiF0mlRkH4ZKxZcOyeSVijpNjiorgCa5tE6T0AH3SisLctx2KitynSbaJRgk2Hj/ufxrBUGsp8DGBYMGjm0BhaZkYnJyAypxbxe24liL40WnyTc+qDxJqnedJnudJvnEiwQepJzOtzAq5IXacUGAmpcT62rykG0lpdQHETsE8j5vX1vj1pA+QzDpqlBgjyZ5JHbifBtqw4QYrtTZB3Gp0+Alu031XeKTxAiVGn3gtM1IcvGCBzA2V+uKmvqDiXoO6Os9jIRTMOQ9DnW7TC6xAKMqYDr92VrafqDuuLPQ46OhsmKHmlQaRnJ0kYpXsic6f2hQX3KfydWcD141qLJipbLig44VlV/BkEvDcnn0xSQSS9hmNnZkH7iwcSxlc5dtF1D/AbWEDHJd0GzmlRAAfNpL7RuiT52sEvdt70hk4TGpHJN4iabvjCXfGYGLizb4iLUg6XJ1fUxlU4NUwwl1B5Yw6q+tw9nuk+9XoemwvCnIVRN6r0aYO8B+v9DyJ/H6e4mFpi3UhTNqxtuQMydvuQ/oMXNJdZ1Qkz1HBzmkw1FcPsOQ8S6kcmC0T9GSVnfBJKqwzZahmXghVtfyNQQkTSXx9+xDc8x8JpFC0ymr6bne7SE1uum8sb6/V2Sj5/2lw/Xg0jY3hY9YTlvH8mPdHOSY/MS1Sv7wqG4fchgpNVTsc9wvFH2lx2BpQ47Ou0orYKZV4VyYQP9rGBfHeo4MgnvDckfcFXP5sebEERQdQG2TSWOdPfQHNCXbGQ4vvwgv5aHuD1KfrSpUrnhth6nn/hNq9To04Mxx2rvjf0estkElkuzQtH8qmIG6WjTQDP8C2V8jMwjGokTdbm/oyhcYJzNFmgN73NHW+l+pQh9UViiysf5BPTis9p593mkaoDVqyXfoESqZGpIsTqlDq9pfKisOHQ7dtlX6TeCTWErkMUlcvQy9YFtwWHbSwlOujbJHugr7pOygc1A4gnxIa5hFgYIhV1AIaWJIFe1TZ2w/vaFO7wFwSX/JYcZo21LGTeAj1hLhq78dwlchbwgLbq7RMuNIhXFZsgOPMC6EVsPcSgUGneeopd1NyCXVGhGDf7rqT5pAF0863AHlPYAFZV88JLEeEiIPypZQGkb8VzChIjsh0P53CA6UnjJlPHOBOodrBZMZ+iwmQkW/NXLUHflrzuD9vVK8XZjCj7VFuyqU9+8RpvsbIRmqdwc/OViCjUVFB0sGziAYlTJNDk+fybBArQY5lwx0fyXCVjJLYTKyz4XREisgLiexGDirKvSXOFyPVCtbGOl2UZWe1SJ79hVM5kNI/v7SOiRcpgJnlEq1LVeGnJ8uJ1SFiTd5zIW5VaHdoZs+eeQMshlKmIFmo9X2YWkXyS1/UlD4hlJ1lzCDfJW/L9Kv+QixZyrURMo9E1JeWxHBpSS+W6C8L25NLMB01JB44XqOTm0h+jsMaVy5SVI1heC5a0FBkMSyJV9r1sajYbQfi3xIvhkrHZU8eINsIR+pVFZ8kl8nOCgsnl3B7Lc72WqbfVw6TV4c6tK1hSpHnTb9p1VWUPiI6nSR53hHx+0gBBPL2u0BmCS+XwB+wRHpt9JiOTMR8Od69QYl+HEO/SnQR8bPrlCn3WxgCNawjVoIwfnhW5hM1T8p/si59WMkq03iY59dOY+CrkS/tu1NXca0JM8RtSEKjMynBi7EldLPGbbxgfxGa9T5WQuYLNJtl3SgVdnkKzNKr25MujZS0cQK3jdwSzyprFiSOvlCbRNxzI2J5QKL/z2u3QMyGKphZh3nwQN1kHgQHJsmBqkKslmkM5Y97zeNsZE5cYAjtteh4t8A/DPEDJgbT6j9Nm0SqISZoXLwXkn8N/YXOpx5ezGjjqhtrc2QuBwNgE2qwaqC9s6t0Xy3HdltfQz0QSD1+4mm9JUq2NlHQu0rPEhGg8STZTDykrixR44M2Fd0iH+HM6+US3yqS5LgEGoX0ay2B2Ay+4PKkZmYbzCqcTZykWRk5ynjHc1PE6wC+ujhVotsY021lJXOPJtE5qLZ1XxETZATpat4SevIbwcoHXmCNsu22VvalzDkmtTV4YkkaBgtkNM9so92uP6AiP3sQ+EJCNqp2wlrCxZgjEpfuZct76i92067hgzaLzRJ9T41qRj6etcxk2u0ulFZsaB+sqVUDuPrkosP6Ttb0nMSl/Y8on9rtINUXW/BAgyp2rZza5Gqwh28I8lkZ3nuUbsEGrPaaodLXQxSY/r6ewk5+u0g8tXb+L4BWjZ0ULSBvwID0DcbUBOODfaHCTxLjCJWi4rq9Kx7yLWBMepfWTXyPjqSaG0bKe0MShu9ZrUgl3cbuwr7Co6MSx7F4saZKm21Ya+aW7ns/ZDAjYklBAmAxvexJAf0GM+7K6+8l4oSGZxSujmj9+R8bPNgt7kbBgVvdZoc23xj1M4ur3qjXdQ/a50mr4Ee+Vf4J4W2y58bNGYa9X5R+ZVCxnmMxNI6TV5I92/gUVGBDX1XWXGGmY2DVnlCdTQuI/CjbiPA7ZbgYPPZ1Sc9HbkawIsISPMA8q7vexjuMimSUYISEL+Xf+edu0e6wPbEI3p/I+aH7+O233w/RESMwW+xSyfi8RCJFTELIrEiZkEkVsQsiMSKmAWRWBGzIBIrYhZEYkXMgkisiFkQiRUxCyKxImZBJFbELIjEipgFkVgRsyASK2IWfFOB/4fL74Tv5d/3bsJvjyixImYB57y3/k/lvxlGp2NHdCNKrIhZEIkVMQsisSJmwX9PCQel6M2GygAAAABJRU5ErkJggg==";
const _imports_6 = "" + buildAssetsURL("usMsg.d1f0abb5.png");
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRoute();
    useRouter();
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const bottomRef = ref();
    const tabRef = ref();
    useElementVisibility(bottomRef);
    const tabIsVisible = useElementVisibility(tabRef);
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannel")), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannelAdd")), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (isPc.value) {
        _push(`<div class="${ssrRenderClass(`w-full flex bg-white h-20 items-center shadow-md z-50 justify-between ${unref(tabIsVisible) ? "" : "fixed top-0"}`)}" data-v-1b60b00d><div class="w-3/4 flex items-center justify-between" data-v-1b60b00d><img class="m-2 h-12"${ssrRenderAttr("src", _imports_0$1)} data-v-1b60b00d>`);
        _push(ssrRenderComponent(CustomTabs, {
          class: "justify-around",
          isPc: isPc.value
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-1b60b00d></div><div class="flex flex-col items-center" data-v-1b60b00d><div class="w-3/4 ph:w-full" data-v-1b60b00d><img class="w-full ph:hidden"${ssrRenderAttr("src", _imports_1)} alt="" data-v-1b60b00d><div class="flex m-10" data-v-1b60b00d><div class="text-lg ph:text-base" data-v-1b60b00d><img${ssrRenderAttr("src", _imports_2)} alt="\u5173\u4E8E\u6211\u4EEC" class="my-8" data-v-1b60b00d><p data-v-1b60b00d>\u300A\u65B0\u5FEB\u62A5\u300B\u7531\u7F8A\u57CE\u665A\u62A5\u62A5\u4E1A\u96C6\u56E2\u4E3B\u529E\uFF0C1998\u5E743\u670830\u65E5\u521B\u520A\uFF0C\u65E5\u5E384\u5F0080\u7248\u3002<br data-v-1b60b00d> \u300A\u65B0\u5FEB\u62A5\u300B\u79C9\u627F\u201C\u5185\u5BB9\u4E3A\u738B\u201D\u7684\u5E02\u573A\u5BFC\u5411\uFF0C\u4EE5\u5173\u6CE8\u6C11\u751F\u3001\u670D\u52A1\u793E\u4F1A\u4E3A\u5B97\u65E8\uFF0C\u4EE5\u201C\u529E\u6700\u53D7\u5E02\u6C11\u559C\u7231\u7684\u62A5\u7EB8\u201D\u4E3A\u76EE\u6807\uFF0C\u4EE5\u65B0\u9510\u7684\u529E\u62A5\u7406\u5FF5\u4E0E\u9C9C\u660E\u7684\u7F16\u8F91\u98CE\u683C\u4E3A\u7279\u8272\uFF0C\u5F3A\u8C03\u65B0\u95FB\u4E0E\u8D44\u8BAF\u7684\u5B9E\u7528\u6027\u3002\u7248\u9762\u8BBE\u8BA1\u65B0\u9896\uFF0C\u89C6\u89C9\u51B2\u51FB\u529B\u5F3A\uFF0C\u5F15\u9886\u5E02\u573A\u6F6E\u6D41\uFF0C\u63D0\u4F9B\u5168\u65B9\u4F4D\u8D44\u8BAF\u3002<br data-v-1b60b00d> \u300A\u65B0\u5FEB\u62A5\u300B\u7684\u91C7\u7F16\u961F\u4F0D\u7D20\u8D28\u9AD8\u3001\u5E74\u8F7B\u5316\uFF0C\u62E5\u6709\u73B0\u4EE3\u7684\u6280\u672F\u624B\u6BB5\u3002\u300A\u65B0\u5FEB\u62A5\u300B\u4EE5\u5E7F\u5DDE\u53CA\u73E0\u4E09\u89D2\u5730\u533A\u4E3A\u4E3B\u9500\u5E02\u573A\uFF0C\u6838\u5FC3\u8BFB\u8005\u662F\u793E\u4F1A\u4E2D\u6700\u5177\u6D3B\u529B\u548C\u6D88\u8D39\u80FD\u529B\u7684\u767D\u9886\u548C\u4E2D\u4EA7\u9636\u5C42\uFF0C\u540C\u65F6\u4E5F\u6DF1\u53D7\u666E\u901A\u57CE\u5E02\u8BFB\u8005\u7684\u559C\u7231\uFF0C\u5177\u6709\u65E5\u76CA\u5E7F\u6CDB\u7684\u5F71\u54CD\u529B\u548C\u826F\u597D\u7684\u5E7F\u544A\u6548\u5E94\u3002 </p><p data-v-1b60b00d>\u56FD\u5185\u7B2C\u4E00\u4EFD\u2015\u2015<br data-v-1b60b00d> \u56FD\u5185\u7B2C\u4E00\u4EFD\u5B9E\u73B0\u5168\u5F69\u5370\u5237\u7684\u5927\u578B\u7EFC\u5408\u6027\u65E5\u62A5\u3002</p><p data-v-1b60b00d>\u5E7F\u544A\u589E\u957F\u6700\u5FEB\u2015\u2015<br data-v-1b60b00d> \u300A\u65B0\u5FEB\u62A5\u300B2002\u5E74\u30012003\u5E74\u8FDE\u7EED\u4E24\u5E74\u6210\u4E3A\u5168\u56FD\u5E73\u9762\u5A92\u4F53\u5E7F\u544A\u589E\u957F\u6700\u5FEB\u7684\u5E73\u9762\u5A92\u4F53\uFF01 </p><p data-v-1b60b00d>\u6700\u6709\u5F71\u54CD\u7684\u4E3B\u6D41\u62A5\u7EB8\u2015\u2015<br data-v-1b60b00d> \u5728\u65B0\u95FB\u4FE1\u606F\u8D28\u91CF\u3001\u5E7F\u544A\u6536\u5165\u548C\u53D1\u884C\u91CF\u4E3A\u6838\u5FC3\u6307\u6807\u7684\u7EFC\u5408\u5F71\u54CD\u529B\u4E0A\uFF0C\u5DF2\u4F4D\u5217\u5E7F\u5DDE\u5730\u533A\u201C\u65E5\u62A5\u7EC4\u56E2\u524D\u4E09\u540D\u201D\uFF0C\u6210\u4E3A\u5E7F\u5DDE\u6700\u6709\u5F71\u54CD\u7684\u4E3B\u6D41\u62A5\u7EB8\u4E4B\u4E00\u3002 </p><p data-v-1b60b00d>\u4E16\u754C\u65E5\u62A5\u53D1\u884C\u91CF\u524D100\u5F3A\u2015\u2015<br data-v-1b60b00d> 2004\u5E74\u30012005\u5E74\uFF0C\u300A\u65B0\u5FEB\u62A5\u300B\u8749\u8054\u201C\u4E16\u754C\u65E5\u62A5\u53D1\u884C\u91CF\u524D100\u5F3A\u201D\uFF012006\u5E74\uFF0C2007\u5E74\u8FDE\u7EED\u4E24\u5E74\u8363\u83B7\u201C\u5341\u5927\u521B\u65B0\u90FD\u5E02\u62A5\u201D\u5956\u9879\uFF01<br data-v-1b60b00d></p><p data-v-1b60b00d>\u4E2D\u56FD\u4F20\u5A92\u5341\u5927\u9886\u519B\u54C1\u724C\u2015\u2015<br data-v-1b60b00d> 2010\u5E74\uFF0C\u8363\u83B7\u201C2001-2010\u4E2D\u56FD\u62A5\u4E1A\uFF08\u90FD\u5E02\u62A5\uFF09\u9886\u519B\u54C1\u724C\u201D\u5956\uFF01<br data-v-1b60b00d>2011\u5E74\u81F32013\u5E74\uFF0C\u8363\u83B7\u4E2D\u56FD\u4F20\u5A92\u5927\u4F1A\u30FB\u91D1\u957F\u57CE\u4F20\u5A92\u5956\u201C2010\u4E2D\u56FD\u6700\u5177\u521B\u65B0\u4F20\u5A92\u201D\u5956\u3001\u201C2011\u4E2D\u56FD\u5341\u5927\u4F20\u64AD\u529B\u90FD\u5E02\u62A5\u201D\u5956\u3001\u201C2012\u4E2D\u56FD\u5341\u5927\u5F71\u54CD\u529B\u90FD\u5E02\u62A5\u201D\u5956\u3002<br data-v-1b60b00d> 2013\u5E74\uFF0C\u8363\u83B7\u201C\u4E2D\u56FD\u4F20\u5A92\u5341\u5927\u9886\u519B\u54C1\u724C\u201D\u5956\u3001\u201C\u4E2D\u56FD\u5E02\u6C11\u559C\u7231\u7684\u5A92\u4F53\u54C1\u724C\u201D\u5956\uFF0C\u4EE5\u53CA\u201C2013\u4F20\u5A92\u4E2D\u56FD\u5E74\u5EA6\u5F71\u54CD\u529B\u90FD\u5E02\u62A5\u201D\u5956\u3002<br data-v-1b60b00d>2014\u5E74\uFF0C\u8363\u83B7\u201C\u6570\u5B57\u51FA\u7248\u8F6C\u578B\u793A\u8303\u5355\u4F4D\u201D\u8363\u8A89\uFF1B<br data-v-1b60b00d>\u65B0\u5FEB\u62A5\u793E\u526F\u603B\u7F16\u8F91\u674E\u6D01\u519B\u8363\u83B7\u4E2D\u56FD\u6444\u5F71\u91D1\u50CF\u5956\uFF1B<br data-v-1b60b00d>\u201C\u8BB0\u5FC62013\u30FB\u4E2D\u56FD\u65B0\u95FB\u6444\u5F71\u76DB\u5178\u201D\u8BC4\u9009\uFF0C\u65B0\u5FEB\u62A5\u6444\u5F71\u8BB0\u8005\u590F\u4E16\u7131\u8363\u83B7\u201C\u5341\u4F73\u6444\u5F71\u8BB0\u8005\u5956\u201D\uFF0C\u65B0\u5FEB\u62A5\u56FE\u7247\u7F16\u8F91\u90ED\u6674\u8363\u83B7\u201C\u5341\u4F73\u56FE\u7247\u7F16\u8F91\u5956\u201D\u3002<br data-v-1b60b00d></p></div><div data-v-1b60b00d><img class="w-[600px] ph:hidden"${ssrRenderAttr("src", _imports_3)} alt="\u5173\u4E8E\u6211\u4EEC" width="100%" data-v-1b60b00d></div></div><img${ssrRenderAttr("src", _imports_4)} alt="\u7248\u6743\u8BF4\u660E" width="100%" class="mt25_bot" data-v-1b60b00d><img${ssrRenderAttr("src", _imports_5)} alt="\u8054\u7CFB\u6211\u4EEC" width="150" class="my-10" data-v-1b60b00d><img${ssrRenderAttr("src", _imports_6)} alt="\u8054\u7CFB\u6211\u4EEC" width="100%" data-v-1b60b00d></div>`);
      if (!unref(tabIsVisible)) {
        _push(ssrRenderComponent(ScrollToTop, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full" data-v-1b60b00d>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/about/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-1b60b00d"]]);

export { index as default };
//# sourceMappingURL=index-aa7be5d0.mjs.map
