import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, mergeProps, unref, createVNode, resolveDynamicComponent, ref, resolveDirective } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderVNode, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrGetDirectiveProps } from 'vue/server-renderer';
import { f as util, u as useBreakpoints, b as breakpointsTailwind, e as StrongTitle, i as useApiFetch } from './CustomTabs-8591f744.mjs';
import { useRouter } from 'vue-router';
import { a as axios } from '../server.mjs';

const _sfc_main$6 = {
  __name: "InfoBar",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-start text-gray-500" }, _attrs))}><div class="mr-4">${ssrInterpolate(__props.data.source || "\u65B0\u5FEB\u62A5")}</div><div class="mr-4">${ssrInterpolate(unref(util).timeFormat(__props.data.time))}</div></div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/InfoBar.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const InfoBar = _sfc_main$6;
const _sfc_main$5 = {
  __name: "NewsItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const formatTitle = (str) => {
      if (str.length > 45) {
        return str.slice(0, 45) + "...";
      } else {
        return str;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: `w-full flex justify-between min-h-32 pb-4 border-b-[1px] border-gray-300 ph:text-sm` }, _attrs))}><div class="flex flex-col justify-between"><div class="text-xl font-medium cursor-pointer mr-3 ph:overflow-ellipsis hover:text-primary ph:max-h-28 ph:max-w-[240px] ph:text-lg">${ssrInterpolate(isPc.value ? props.data.listTitle : formatTitle(props.data.listTitle))}</div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: (_b = (_a = props.data) == null ? void 0 : _a.metaInfo) == null ? void 0 : _b.source, comment: (_c = props == null ? void 0 : props.data) == null ? void 0 : _c.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
      if (props.data.metaInfo.listStyle !== 2) {
        _push(`<img${ssrRenderAttrs(mergeProps({ class: "h-full ph:w-28 w-44 rounded-lg object-cover" }, ssrGetDirectiveProps(_ctx, _directive_lazy, props.data.metaInfo.thumbnails[0])))}>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NewsItem.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const NewsItem = _sfc_main$5;
const _sfc_main$4 = {
  __name: "ImageListItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><div class="text-xl font-medium cursor-pointer ph:text-lg hover:text-primary">${ssrInterpolate(props.data.listTitle)}</div><div class="w-full flex"><!--[-->`);
      ssrRenderList(props.data.metaInfo.thumbnails, (item) => {
        _push(`<div class="w-full px-2 py-1"><img${ssrRenderAttrs(mergeProps({
          alt: item,
          class: "w-full h-44 ph:h-20 object-cover rounded-lg"
        }, ssrGetDirectiveProps(_ctx, _directive_lazy, item)))}></div>`);
      });
      _push(`<!--]--></div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: props.data.metaInfo.source, comment: props.data.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/ImageListItem.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const ImageListItem = _sfc_main$4;
const _sfc_main$3 = {
  __name: "NarrowImage",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><img${ssrRenderAttrs(mergeProps({ class: "w-full rounded-xl" }, ssrGetDirectiveProps(_ctx, _directive_lazy, unref(util).replaceImgPath(props.data.metaInfo.thumbnails[0]))))}></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NarrowImage.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const NarrowImage = _sfc_main$3;
const _sfc_main$2 = {
  __name: "NewsItemDetail",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: `w-full flex justify-between min-h-32 pb-4 border-b-[1px] border-gray-300` }, _attrs))}><div class="flex flex-col justify-between"><div class="text-xl font-medium cursor-pointer hover:text-primary">${ssrInterpolate(props.data.listTitle)}</div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: props.data.source, comment: props.data.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
      if (props.data.listStyle !== 2) {
        _push(`<img${ssrRenderAttr("src", props.data.thumbnails[0])} class="h-full w-44 rounded-lg object-cover">`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NewsItemDetail.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const NewsItemDetail = _sfc_main$2;
const _sfc_main$1 = {
  __name: "ListItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object
    },
    plainData: {
      type: Object
    }
  },
  setup(__props) {
    const props = __props;
    const componentsList = {
      0: props.data ? NewsItem : NewsItemDetail,
      1: ImageListItem,
      3: NewsItem,
      2: NewsItem,
      4: NarrowImage
    };
    const key = props.data ? props.data.metaInfo.listStyle : props.plainData.listStyle;
    const finalData = props.data ? props.data : props.plainData;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(componentsList[unref(key)]), mergeProps({
        data: unref(finalData),
        class: "mb-6"
      }, _attrs), null), _parent);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/ListItem.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ListItem = _sfc_main$1;
const _imports_2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAATCAYAAAByUDbMAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAEaSURBVDiNrdQxTsMwFAbg/0VcAMmtegIsMVVcAHMBku70CBUTc9O5Y9eKJd3TnKCWuACru7EhEglOULNg1Ch+doJ4o1/y+fk9J4SfMJnIYbEEAAL0VdXcYWAQAJhUWF9SVg0NwZJjKg5c0mQiH1QZV5ULWTU0KUp1AhQAfMxn7AYXIeh1JDHebe3pbG2029/WD5m3n0kIWqinzjoBalKUqjfGQS7ckaNYDAL4vnWwGARrV1yqhT1f30ehP0+z5QC6DkCdym5qwz5IgBoXZX9sWhtMAyCIliGwM4CNXkfB3lgfkL+0BO+oN3oN+fn25cu9z2fai8l9k3MVvCweLy3QfjFwz37/V8dUHKz7TAir801c0xNAc1X9e3wDac9mu/xxGCQAAAAASUVORK5CYII=";
const _imports_1 = "" + buildAssetsURL("ygaba.5c590e6b.png");
const _sfc_main = {
  __name: "SideBar",
  __ssrInlineRender: true,
  setup(__props) {
    axios().provide.axios;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const router = useRouter();
    const featuresList = ref([]);
    const requestData = async () => {
      const { data } = await useApiFetch("/articles?chnlId=430&visibility=1&page=0&size=10");
      featuresList.value = data._rawValue.data;
    };
    requestData();
    const linkRender = (data) => {
      return util.renderLink(data, router, isPc);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="flex flex-col">`);
      _push(ssrRenderComponent(StrongTitle, {
        name: "\u8F7B\u62A5\u7EB8",
        isCurrent: true,
        class: "mb-3"
      }, null, _parent));
      _push(`<a href="https://epaper.xkb.com.cn/" target="_blank"><img src="https://epaper.xkb.com.cn/index.php?s=/index/firstedition/" class="w-full h-full rounded-lg"></a></div><div class="flex flex-col sticky top-[80px] bg-white">`);
      _push(ssrRenderComponent(StrongTitle, {
        name: "\u4E13\u9898",
        isCurrent: true,
        class: "mb-3 mt-4"
      }, null, _parent));
      _push(`<div class="bg-teal-50 rounded-xl p-3"><!--[-->`);
      ssrRenderList(featuresList.value, (item) => {
        _push(`<div class="mr-4 flex items-center mb-2 cursor-pointer"><img${ssrRenderAttr("src", _imports_2)} class="h-3 w-3"><a${ssrRenderAttr("href", linkRender(item))} target="_blank">${ssrInterpolate(item.title)}</a></div>`);
      });
      _push(`<!--]--></div><div class="full flex items-start ph:px-1 ph:py-3 flex-col text-sm mt-2 text-gray-400"><div><a class="active:text-yellow-400 hover:text-yellow-400" href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank">\u7CA4ICP\u590710220059\u53F7 </a></div><div class="flex items-center"><img class="w-4"${ssrRenderAttr("src", _imports_1)} alt=""><a class="active:text-yellow-400 hover:text-yellow-400" href="https://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602008415" target="_blank">\u7CA4\u516C\u7F51\u5B89\u5907 44010602008415\u53F7 </a></div></div></div><div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SideBar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SideBar = _sfc_main;

export { InfoBar as I, ListItem as L, SideBar as S, _imports_2 as _ };
//# sourceMappingURL=SideBar-5641be83.mjs.map
