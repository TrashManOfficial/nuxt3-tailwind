const index_vue_vue_type_style_index_0_scoped_8a2a50e2_lang = ".mask[data-v-8a2a50e2]{background:linear-gradient(180deg,transparent,rgba(3,47,50,.9));height:100%;opacity:1;position:absolute;width:100%}.container[data-v-8a2a50e2]{overflow:hidden;white-space:nowrap;width:340px}.scroll-text[data-v-8a2a50e2]{animation:scroll-8a2a50e2 12s linear infinite;display:inline-block}@keyframes scroll-8a2a50e2{0%{transform:translateX(20px)}to{transform:translateX(-100%)}}";

const indexStyles_56a85194 = [index_vue_vue_type_style_index_0_scoped_8a2a50e2_lang];

export { indexStyles_56a85194 as default };
//# sourceMappingURL=index-styles.56a85194.mjs.map
