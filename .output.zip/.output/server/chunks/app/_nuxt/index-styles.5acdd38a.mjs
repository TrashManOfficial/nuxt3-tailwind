const index_vue_vue_type_style_index_0_scoped_1b60b00d_lang = ".opacityLinear[data-v-1b60b00d]{background:linear-gradient(180deg,#169daa 10%,#fff 60%)}";

const indexStyles_5acdd38a = [index_vue_vue_type_style_index_0_scoped_1b60b00d_lang];

export { indexStyles_5acdd38a as default };
//# sourceMappingURL=index-styles.5acdd38a.mjs.map
