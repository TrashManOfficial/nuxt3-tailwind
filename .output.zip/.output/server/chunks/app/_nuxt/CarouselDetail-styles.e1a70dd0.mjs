const CarouselDetail_vue_vue_type_style_index_0_scoped_9eaa3dc0_lang = ".opacityLinear[data-v-9eaa3dc0]{background:linear-gradient(0deg,rgba(0,0,0,.7) 10%,rgba(0,0,0,.01))}";

const CarouselDetailStyles_e1a70dd0 = [CarouselDetail_vue_vue_type_style_index_0_scoped_9eaa3dc0_lang];

export { CarouselDetailStyles_e1a70dd0 as default };
//# sourceMappingURL=CarouselDetail-styles.e1a70dd0.mjs.map
