import { H as Head, _ as __nuxt_component_1 } from './client-only-1859eae7.mjs';
import { ref, withAsyncContext, withCtx, createVNode, toDisplayString, unref, useSSRContext, watch, mergeProps } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderClass, ssrRenderList, ssrRenderAttrs } from 'vue/server-renderer';
import { a as useElementVisibility, u as useBreakpoints, c as channelStore, _ as _imports_0$1, C as CustomTabs, e as StrongTitle, f as util, S as ScrollToTop, F as Footer, b as breakpointsTailwind, g as useElementHover, h as useIntervalFn } from './CustomTabs-8591f744.mjs';
import { I as InfoBar, L as ListItem, S as SideBar } from './SideBar-5641be83.mjs';
import { S as SearchBar } from './SearchBar-2568e8c4.mjs';
import { useRoute, useRouter } from 'vue-router';
import { u as useHead, _ as _export_sfc } from '../server.mjs';
import { parse } from 'node-html-parser';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-devtools-stub';
import 'axios';
import 'vue3-lazyload';

const _sfc_main$1 = {
  __name: "CarouselDetail",
  __ssrInlineRender: true,
  props: {
    list: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    useRouter();
    const carouselRef = ref();
    let isCarouselHover = useElementHover(carouselRef);
    const currentVisibleImg = ref(0);
    const addImgIndex = () => {
      if (currentVisibleImg.value >= props.list.length - 1) {
        currentVisibleImg.value = 0;
      } else {
        currentVisibleImg.value++;
      }
    };
    const { pause, resume } = useIntervalFn(() => {
      addImgIndex();
    }, 4e3);
    watch(isCarouselHover, (value) => {
      if (!value) {
        resume();
      } else {
        pause();
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "mx-auto rounded-lg",
        ref_key: "carouselRef",
        ref: carouselRef
      }, _attrs))} data-v-9eaa3dc0><div class="relative" data-v-9eaa3dc0><div class="overflow-hidden relative h-[550px] rounded-lg" data-v-9eaa3dc0><!--[-->`);
      ssrRenderList(props.list, (item, index) => {
        _push(`<div class="${ssrRenderClass(`duration-700 ease-in-out ${currentVisibleImg.value === index ? "" : "hidden"}`)}" data-v-9eaa3dc0><span class="absolute top-1/2 left-1/2 text-2xl font-semibold text-white -translate-x-1/2 -translate-y-1/2 sm:text-3xl dark:text-gray-800" data-v-9eaa3dc0>First Slide</span><img${ssrRenderAttr("src", item.appfile)} class="h-full block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 object-cover" alt="" data-v-9eaa3dc0><div class="flex p-1 absolute bottom-0 left-1/2 z-30 space-x-3 -translate-x-1/2 bg-black w-full min-h-11 opacityLinear text-2xl text-white justify-center items-center rounded-b-lg" data-v-9eaa3dc0>${ssrInterpolate(item.appdesc)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex absolute top-0 left-0 z-0 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-v-9eaa3dc0><span class="inline-flex justify-center items-center w-8 h-8 rounded-full bg-gray-800/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none" data-v-9eaa3dc0><svg class="w-5 h-5 text-gray-800 sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-v-9eaa3dc0><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" data-v-9eaa3dc0></path></svg><span class="hidden" data-v-9eaa3dc0>Previous</span></span></div><div class="flex absolute top-0 right-0 z-0 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-v-9eaa3dc0><span class="inline-flex justify-center items-center w-8 h-8 rounded-full bg-gray-800/30 dark:bg-gray-800/30 group-hover:bg-white/50 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none" data-v-9eaa3dc0><svg class="w-5 h-5 text-gray-800 sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-v-9eaa3dc0><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" data-v-9eaa3dc0></path></svg><span class="hidden" data-v-9eaa3dc0>Next</span></span></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/CarouselDetail.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CarouselDetail = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-9eaa3dc0"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const tabRef = ref();
    const tabIsVisible = useElementVisibility(tabRef);
    const { query } = useRoute();
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const ArticleDetail = ref({});
    const str = ref("");
    useHead({
      meta: [
        { name: "referrer", content: "no-referrer" }
      ]
    });
    const imgList = ref([]);
    const videoDetail = ref({});
    const type = ref(void 0);
    const router = useRouter();
    ref();
    const commentList = ref([]);
    const onSearch = (text) => {
      const herf = router.resolve({
        path: "search",
        query: {
          keyword: text
        }
      });
      window.open(herf.href, "_blank");
    };
    const handleVideoInHtml = (html) => {
      const doc = parse(html);
      const imgTags = doc.querySelectorAll("img[data-videourl]");
      if (!imgTags.length) {
        return html;
      }
      imgTags.forEach((img) => {
        const video = parse("<video></video>");
        const videoSrc = img.getAttribute("data-videourl");
        video.firstChild.setAttribute("src", videoSrc);
        video.firstChild.setAttribute("alt", img.getAttribute("alt"));
        video.firstChild.setAttribute("class", img.getAttribute("class"));
        video.firstChild.setAttribute("style", img.getAttribute("style"));
        video.firstChild.setAttribute("class", "m-auto");
        video.firstChild.setAttribute("controls", true);
        img.replaceWith(video);
      });
      const newHtml = doc.toString();
      return newHtml;
    };
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannel")), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannelAdd")), await __temp, __restore();
    const handleArticle = async (data) => {
      ArticleDetail.value = data;
      type.value = data.docType + 0;
      if (type.value === 1) {
        ArticleDetail.value = channelStore.state.articleDetail;
        const url = data.contentUrl;
        const htmlData = await $fetch(`${url}`);
        str.value = handleVideoInHtml(htmlData.htmlContent);
        return;
      }
      if (type.value === 2) {
        imgList.value = data.metaInfo.appendixs;
      }
      if (type.value === 7) {
        str.value = data.metaInfo.videoDoc.htmlContent;
        videoDetail.value = data.metaInfo.videoDoc;
      }
    };
    const readCount = () => {
      const id = query.id;
      channelStore.dispatch("postReadCount", id);
    };
    const getArticleDetail = async () => {
      await channelStore.dispatch("getArticleDetails", query.id);
      await handleArticle(channelStore.state.articleDetail);
      readCount();
    };
    [__temp, __restore] = withAsyncContext(() => getArticleDetail()), await __temp, __restore();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
      const _component_Head = Head;
      const _component_ClientOnly = __nuxt_component_1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2, _e2, _f2, _g2, _h2;
          if (_push2) {
            _push2(`<title${_scopeId}>${ssrInterpolate(ArticleDetail.value.title)}</title><meta name="description"${ssrRenderAttr("content", (_b2 = (_a2 = ArticleDetail.value) == null ? void 0 : _a2.metaInfo) == null ? void 0 : _b2.shareDesc)}${_scopeId}><meta name="keywords"${ssrRenderAttr("content", (_d2 = (_c2 = ArticleDetail.value) == null ? void 0 : _c2.metaInfo) == null ? void 0 : _d2.keyWords)}${_scopeId}>`);
          } else {
            return [
              createVNode("title", null, toDisplayString(ArticleDetail.value.title), 1),
              createVNode("meta", {
                name: "description",
                content: (_f2 = (_e2 = ArticleDetail.value) == null ? void 0 : _e2.metaInfo) == null ? void 0 : _f2.shareDesc
              }, null, 8, ["content"]),
              createVNode("meta", {
                name: "keywords",
                content: (_h2 = (_g2 = ArticleDetail.value) == null ? void 0 : _g2.metaInfo) == null ? void 0 : _h2.keyWords
              }, null, 8, ["content"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="${ssrRenderClass(`w-full flex bg-white h-20 items-center shadow-md z-50 justify-center ${unref(tabIsVisible) ? "" : "fixed top-0"}`)}"><div class="w-[1500px] flex items-center justify-between"><img class="m-2 h-12"${ssrRenderAttr("src", _imports_0$1)} alt="\u65B0\u5FEB\u7F51logo">`);
      _push(ssrRenderComponent(CustomTabs, {
        class: "justify-around",
        isPc: isPc.value
      }, null, _parent));
      _push(`</div><div class="w-1/4 mx-2">`);
      _push(ssrRenderComponent(SearchBar, { onOnSearch: onSearch }, null, _parent));
      _push(`</div></div><div class="flex justify-center"><div class="w-[1100px] flex ph:w-full justify-center mt-3">`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`<div class="max-w-[750px] pr-6 flex flex-col ph:w-full"><div><div class="text-3xl font-black my-6">${ssrInterpolate(ArticleDetail.value.title)}</div>`);
      _push(ssrRenderComponent(InfoBar, {
        class: "mb-3",
        data: { source: (_b = (_a = ArticleDetail.value) == null ? void 0 : _a.metaInfo) == null ? void 0 : _b.source, time: ArticleDetail.value.docPubTime }
      }, null, _parent));
      _push(`</div>`);
      if (type.value === 1) {
        _push(`<div class="text-justify contentSpe docContentBox">${str.value}</div>`);
      } else {
        _push(`<!---->`);
      }
      if (type.value === 2) {
        _push(ssrRenderComponent(CarouselDetail, {
          list: imgList.value,
          class: "w-full"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (type.value === 7) {
        _push(`<div><video${ssrRenderAttr("poster", videoDetail.value.coverPic)} controls class="m-auto"><source${ssrRenderAttr("src", videoDetail.value.url)} type="video/mp4"></video><div>${str.value}</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div><div class="text-gray-400">`);
      if (((_d = (_c = ArticleDetail.value) == null ? void 0 : _c.metaInfo) == null ? void 0 : _d.responsileEditor) || ((_f = (_e = ArticleDetail.value) == null ? void 0 : _e.metaInfo) == null ? void 0 : _f.editor)) {
        _push(`<div> \u8D23\u7F16\uFF1A${ssrInterpolate(((_h = (_g = ArticleDetail.value) == null ? void 0 : _g.metaInfo) == null ? void 0 : _h.responsileEditor) || ((_j = (_i = ArticleDetail.value) == null ? void 0 : _i.metaInfo) == null ? void 0 : _j.editor))}</div>`);
      } else {
        _push(`<!---->`);
      }
      if ((_l = (_k = ArticleDetail.value) == null ? void 0 : _k.metaInfo) == null ? void 0 : _l.proofread) {
        _push(`<div>\u6821\u5BF9\uFF1A${ssrInterpolate((_n = (_m = ArticleDetail.value) == null ? void 0 : _m.metaInfo) == null ? void 0 : _n.proofread)}</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><hr><div class="my-4 text-gray-400"> \u7279\u522B\u58F0\u660E\uFF1A\u4EE5\u4E0A\u5185\u5BB9\u7248\u6743\u5747\u5C5E\u5E7F\u4E1C\u65B0\u5FEB\u62A5\u793E\u6240\u6709\uFF08\u6CE8\u660E\u5176\u4ED6\u6765\u6E90\u7684\u5185\u5BB9\u9664\u5916\uFF09\uFF0C\u4EFB\u4F55\u5A92\u4F53\u3001\u7F51\u7AD9\u6216\u4E2A\u4EBA\u672A\u7ECF\u672C\u62A5\u534F\u8BAE\u6388\u6743\u4E0D\u5F97\u8F6C\u8F7D\u3001\u94FE\u63A5\u3001\u8F6C\u8D34\u6216\u4EE5\u5176\u4ED6\u65B9\u5F0F\u590D\u5236\u53D1\u5E03/\u53D1\u8868\u3002\u534F\u8BAE\u6388\u6743\u8F6C\u8F7D\u8054\u7CFB\uFF1A\uFF08020\uFF0987133906\u3002 </div><hr></div>`);
      if ((_q = (_p = (_o = ArticleDetail.value) == null ? void 0 : _o.metaInfo) == null ? void 0 : _p.relatedDoc) == null ? void 0 : _q.length) {
        _push(`<div>`);
        _push(ssrRenderComponent(StrongTitle, {
          name: "\u63A8\u8350\u9605\u8BFB",
          isCurrent: true,
          class: "mb-4"
        }, null, _parent));
        _push(`<!--[-->`);
        ssrRenderList((_s = (_r = ArticleDetail.value) == null ? void 0 : _r.metaInfo) == null ? void 0 : _s.relatedDoc, (item) => {
          _push(`<div>`);
          _push(ssrRenderComponent(ListItem, { plainData: item }, null, _parent));
          _push(`</div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (commentList.value.length) {
        _push(`<div>`);
        _push(ssrRenderComponent(StrongTitle, {
          name: `\u8BC4\u8BBA\u56DE\u590D\uFF08${commentList.value.length}\uFF09`,
          isCurrent: true,
          class: "my-4"
        }, null, _parent));
        _push(`<!--[-->`);
        ssrRenderList(commentList.value, (item) => {
          _push(`<div><div class="flex items-start w-full"><div><img class="h-12 w-12 rounded-full"${ssrRenderAttr("src", item.headUrl)} alt=""></div><div class="w-full ml-5"><div class="flex justify-between text-lg items-center"><div class="text-xl font-bold">${ssrInterpolate(item.publisherFullname)}</div><div>${ssrInterpolate(`\u70B9\u8D5E\u6570\uFF1A` + item.favoriteCount)}</div></div><div class="mt-3 mb-4">${ssrInterpolate(item.content)}</div><div><div>${ssrInterpolate(unref(util).timeFormat(item.crDate))}</div><div></div></div></div></div></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="w-3/12 ph:hidden pl-3">`);
      _push(ssrRenderComponent(SideBar, null, null, _parent));
      _push(`</div></div></div>`);
      if (!unref(tabIsVisible)) {
        _push(ssrRenderComponent(ScrollToTop, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full">`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/detail/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-7067fd2a.mjs.map
