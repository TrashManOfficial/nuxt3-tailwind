import{m as e}from"./entry.42616e9c.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
