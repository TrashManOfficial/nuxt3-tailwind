import{G as e}from"./entry.3409534e.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
