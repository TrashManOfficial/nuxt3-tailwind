globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { computed, ref, useSSRContext, watchEffect, watch, mergeProps, nextTick, withCtx, createVNode, toDisplayString, unref, createTextVNode, resolveDynamicComponent, reactive, getCurrentScope, onScopeDispose, isRef, toRef as toRef$1, getCurrentInstance, onServerPrefetch, readonly, customRef, resolveDirective } from 'vue';
import { ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderComponent, ssrRenderStyle, ssrRenderVNode, ssrRenderSlot, ssrGetDirectiveProps } from 'vue/server-renderer';
import { useRouter, useRoute } from 'vue-router';
import { Bars3BottomRightIcon, XMarkIcon } from '@heroicons/vue/24/solid';
import { _ as _export_sfc, a as axios, c as createStore, u as useRuntimeConfig, b as useNuxtApp, d as createError } from '../server.mjs';
import { hash } from 'ohash';

const getDefault = () => null;
function useAsyncData(...args) {
  var _a2, _b, _c, _d, _e, _f;
  var _a;
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  let [key, handler, options = {}] = args;
  if (typeof key !== "string") {
    throw new TypeError("[nuxt] [asyncData] key must be a string.");
  }
  if (typeof handler !== "function") {
    throw new TypeError("[nuxt] [asyncData] handler must be a function.");
  }
  options.server = (_a2 = options.server) != null ? _a2 : true;
  options.default = (_b = options.default) != null ? _b : getDefault;
  options.lazy = (_c = options.lazy) != null ? _c : false;
  options.immediate = (_d = options.immediate) != null ? _d : true;
  const nuxt = useNuxtApp();
  const getCachedData = () => nuxt.isHydrating ? nuxt.payload.data[key] : nuxt.static.data[key];
  const hasCachedData = () => getCachedData() !== void 0;
  if (!nuxt._asyncData[key]) {
    nuxt._asyncData[key] = {
      data: ref((_f = (_e = getCachedData()) != null ? _e : (_a = options.default) == null ? void 0 : _a.call(options)) != null ? _f : null),
      pending: ref(!hasCachedData()),
      error: toRef$1(nuxt.payload._errors, key)
    };
  }
  const asyncData = { ...nuxt._asyncData[key] };
  asyncData.refresh = asyncData.execute = (opts = {}) => {
    if (nuxt._asyncDataPromises[key]) {
      if (opts.dedupe === false) {
        return nuxt._asyncDataPromises[key];
      }
      nuxt._asyncDataPromises[key].cancelled = true;
    }
    if (opts._initial && hasCachedData()) {
      return getCachedData();
    }
    asyncData.pending.value = true;
    const promise = new Promise(
      (resolve, reject) => {
        try {
          resolve(handler(nuxt));
        } catch (err) {
          reject(err);
        }
      }
    ).then((_result) => {
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      let result = _result;
      if (options.transform) {
        result = options.transform(_result);
      }
      if (options.pick) {
        result = pick(result, options.pick);
      }
      asyncData.data.value = result;
      asyncData.error.value = null;
    }).catch((error) => {
      var _a3;
      var _a22;
      if (promise.cancelled) {
        return nuxt._asyncDataPromises[key];
      }
      asyncData.error.value = error;
      asyncData.data.value = unref((_a3 = (_a22 = options.default) == null ? void 0 : _a22.call(options)) != null ? _a3 : null);
    }).finally(() => {
      if (promise.cancelled) {
        return;
      }
      asyncData.pending.value = false;
      nuxt.payload.data[key] = asyncData.data.value;
      if (asyncData.error.value) {
        nuxt.payload._errors[key] = createError(asyncData.error.value);
      }
      delete nuxt._asyncDataPromises[key];
    });
    nuxt._asyncDataPromises[key] = promise;
    return nuxt._asyncDataPromises[key];
  };
  const initialFetch = () => asyncData.refresh({ _initial: true });
  const fetchOnServer = options.server !== false && nuxt.payload.serverRendered;
  if (fetchOnServer && options.immediate) {
    const promise = initialFetch();
    if (getCurrentInstance()) {
      onServerPrefetch(() => promise);
    } else {
      nuxt.hook("app:created", () => promise);
    }
  }
  const asyncDataPromise = Promise.resolve(nuxt._asyncDataPromises[key]).then(() => asyncData);
  Object.assign(asyncDataPromise, asyncData);
  return asyncDataPromise;
}
function pick(obj, keys) {
  const newObj = {};
  for (const key of keys) {
    newObj[key] = obj[key];
  }
  return newObj;
}
function useRequestFetch() {
  var _a;
  const event = (_a = useNuxtApp().ssrContext) == null ? void 0 : _a.event;
  return (event == null ? void 0 : event.$fetch) || globalThis.$fetch;
}
function useFetch(request, arg1, arg2) {
  const [opts = {}, autoKey] = typeof arg1 === "string" ? [{}, arg1] : [arg1, arg2];
  const _key = opts.key || hash([autoKey, unref(opts.baseURL), typeof request === "string" ? request : "", unref(opts.params || opts.query)]);
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useFetch] key must be a string: " + _key);
  }
  if (!request) {
    throw new Error("[nuxt] [useFetch] request is missing.");
  }
  const key = _key === autoKey ? "$f" + _key : _key;
  const _request = computed(() => {
    let r = request;
    if (typeof r === "function") {
      r = r();
    }
    return unref(r);
  });
  if (!opts.baseURL && typeof _request.value === "string" && _request.value.startsWith("//")) {
    throw new Error('[nuxt] [useFetch] the request URL must not start with "//".');
  }
  const {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    watch: watch2,
    immediate,
    ...fetchOptions
  } = opts;
  const _fetchOptions = reactive({
    ...fetchOptions,
    cache: typeof opts.cache === "boolean" ? void 0 : opts.cache
  });
  const _asyncDataOptions = {
    server,
    lazy,
    default: defaultFn,
    transform,
    pick: pick2,
    immediate,
    watch: watch2 === false ? [] : [_fetchOptions, _request, ...watch2 || []]
  };
  let controller;
  const asyncData = useAsyncData(key, () => {
    var _a;
    (_a = controller == null ? void 0 : controller.abort) == null ? void 0 : _a.call(controller);
    controller = typeof AbortController !== "undefined" ? new AbortController() : {};
    const isLocalFetch = typeof _request.value === "string" && _request.value.startsWith("/");
    let _$fetch = opts.$fetch || globalThis.$fetch;
    if (!opts.$fetch && isLocalFetch) {
      _$fetch = useRequestFetch();
    }
    return _$fetch(_request.value, { signal: controller.signal, ..._fetchOptions });
  }, _asyncDataOptions);
  return asyncData;
}
const _imports_0$2 = "" + buildAssetsURL("logo.65bd217b.png");
function tryOnScopeDispose(fn) {
  if (getCurrentScope()) {
    onScopeDispose(fn);
    return true;
  }
  return false;
}
function toValue(r) {
  return typeof r === "function" ? r() : unref(r);
}
const isClient = false;
const notNullish = (val) => val != null;
const noop = () => {
};
function increaseWithUnit(target, delta) {
  var _a;
  if (typeof target === "number")
    return target + delta;
  const value = ((_a = target.match(/^-?[0-9]+\.?[0-9]*/)) == null ? void 0 : _a[0]) || "";
  const unit = target.slice(value.length);
  const result = parseFloat(value) + delta;
  if (Number.isNaN(result))
    return target;
  return result + unit;
}
function toRef(...args) {
  if (args.length !== 1)
    return toRef$1(...args);
  const r = args[0];
  return typeof r === "function" ? readonly(customRef(() => ({ get: r, set: noop }))) : ref(r);
}
function useIntervalFn(cb, interval = 1e3, options = {}) {
  const {
    immediate = true,
    immediateCallback = false
  } = options;
  let timer = null;
  const isActive = ref(false);
  function clean() {
    if (timer) {
      clearInterval(timer);
      timer = null;
    }
  }
  function pause() {
    isActive.value = false;
    clean();
  }
  function resume() {
    const intervalValue = toValue(interval);
    if (intervalValue <= 0)
      return;
    isActive.value = true;
    if (immediateCallback)
      cb();
    clean();
    timer = setInterval(cb, intervalValue);
  }
  if (immediate && isClient)
    resume();
  if (isRef(interval) || typeof interval === "function") {
    const stopWatch = watch(interval, () => {
      if (isActive.value && isClient)
        resume();
    });
    tryOnScopeDispose(stopWatch);
  }
  tryOnScopeDispose(pause);
  return {
    isActive,
    pause,
    resume
  };
}
function unrefElement(elRef) {
  var _a;
  const plain = toValue(elRef);
  return (_a = plain == null ? void 0 : plain.$el) != null ? _a : plain;
}
const defaultWindow = void 0;
function useEventListener(...args) {
  let target;
  let events;
  let listeners;
  let options;
  if (typeof args[0] === "string" || Array.isArray(args[0])) {
    [events, listeners, options] = args;
    target = defaultWindow;
  } else {
    [target, events, listeners, options] = args;
  }
  if (!target)
    return noop;
  if (!Array.isArray(events))
    events = [events];
  if (!Array.isArray(listeners))
    listeners = [listeners];
  const cleanups = [];
  const cleanup = () => {
    cleanups.forEach((fn) => fn());
    cleanups.length = 0;
  };
  const register = (el, event, listener, options2) => {
    el.addEventListener(event, listener, options2);
    return () => el.removeEventListener(event, listener, options2);
  };
  const stopWatch = watch(
    () => [unrefElement(target), toValue(options)],
    ([el, options2]) => {
      cleanup();
      if (!el)
        return;
      cleanups.push(
        ...events.flatMap((event) => {
          return listeners.map((listener) => register(el, event, listener, options2));
        })
      );
    },
    { immediate: true, flush: "post" }
  );
  const stop = () => {
    stopWatch();
    cleanup();
  };
  tryOnScopeDispose(stop);
  return stop;
}
function useMounted() {
  const isMounted = ref(false);
  if (getCurrentInstance())
    ;
  return isMounted;
}
function useSupported(callback) {
  const isMounted = useMounted();
  return computed(() => {
    isMounted.value;
    return Boolean(callback());
  });
}
function useMediaQuery(query, options = {}) {
  const { window: window2 = defaultWindow } = options;
  const isSupported = useSupported(() => window2 && "matchMedia" in window2 && "undefined".matchMedia === "function");
  let mediaQuery;
  const matches = ref(false);
  const cleanup = () => {
    if (!mediaQuery)
      return;
    if ("removeEventListener" in mediaQuery)
      mediaQuery.removeEventListener("change", update);
    else
      mediaQuery.removeListener(update);
  };
  const update = () => {
    if (!isSupported.value)
      return;
    cleanup();
    mediaQuery = window2.matchMedia(toRef(query).value);
    matches.value = !!(mediaQuery == null ? void 0 : mediaQuery.matches);
    if (!mediaQuery)
      return;
    if ("addEventListener" in mediaQuery)
      mediaQuery.addEventListener("change", update);
    else
      mediaQuery.addListener(update);
  };
  watchEffect(update);
  tryOnScopeDispose(() => cleanup());
  return matches;
}
const breakpointsTailwind = {
  "sm": 640,
  "md": 768,
  "lg": 1024,
  "xl": 1280,
  "2xl": 1536
};
function useBreakpoints(breakpoints, options = {}) {
  function getValue(k, delta) {
    let v = breakpoints[k];
    if (delta != null)
      v = increaseWithUnit(v, delta);
    if (typeof v === "number")
      v = `${v}px`;
    return v;
  }
  const { window: window2 = defaultWindow } = options;
  function match(query) {
    if (!window2)
      return false;
    return window2.matchMedia(query).matches;
  }
  const greaterOrEqual = (k) => {
    return useMediaQuery(`(min-width: ${getValue(k)})`, options);
  };
  const shortcutMethods = Object.keys(breakpoints).reduce((shortcuts, k) => {
    Object.defineProperty(shortcuts, k, {
      get: () => greaterOrEqual(k),
      enumerable: true,
      configurable: true
    });
    return shortcuts;
  }, {});
  return Object.assign(shortcutMethods, {
    greater(k) {
      return useMediaQuery(`(min-width: ${getValue(k, 0.1)})`, options);
    },
    greaterOrEqual,
    smaller(k) {
      return useMediaQuery(`(max-width: ${getValue(k, -0.1)})`, options);
    },
    smallerOrEqual(k) {
      return useMediaQuery(`(max-width: ${getValue(k)})`, options);
    },
    between(a, b) {
      return useMediaQuery(`(min-width: ${getValue(a)}) and (max-width: ${getValue(b, -0.1)})`, options);
    },
    isGreater(k) {
      return match(`(min-width: ${getValue(k, 0.1)})`);
    },
    isGreaterOrEqual(k) {
      return match(`(min-width: ${getValue(k)})`);
    },
    isSmaller(k) {
      return match(`(max-width: ${getValue(k, -0.1)})`);
    },
    isSmallerOrEqual(k) {
      return match(`(max-width: ${getValue(k)})`);
    },
    isInBetween(a, b) {
      return match(`(min-width: ${getValue(a)}) and (max-width: ${getValue(b, -0.1)})`);
    },
    current() {
      const points = Object.keys(breakpoints).map((i) => [i, greaterOrEqual(i)]);
      return computed(() => points.filter(([, v]) => v.value).map(([k]) => k));
    }
  });
}
function useElementHover(el, options = {}) {
  const {
    delayEnter = 0,
    delayLeave = 0,
    window: window2 = defaultWindow
  } = options;
  const isHovered = ref(false);
  let timer;
  const toggle = (entering) => {
    const delay = entering ? delayEnter : delayLeave;
    if (timer) {
      clearTimeout(timer);
      timer = void 0;
    }
    if (delay)
      timer = setTimeout(() => isHovered.value = entering, delay);
    else
      isHovered.value = entering;
  };
  if (!window2)
    return isHovered;
  useEventListener(el, "mouseenter", () => toggle(true), { passive: true });
  useEventListener(el, "mouseleave", () => toggle(false), { passive: true });
  return isHovered;
}
function useIntersectionObserver(target, callback, options = {}) {
  const {
    root,
    rootMargin = "0px",
    threshold = 0.1,
    window: window2 = defaultWindow,
    immediate = true
  } = options;
  const isSupported = useSupported(() => window2 && "IntersectionObserver" in window2);
  const targets = computed(() => {
    const _target = toValue(target);
    return (Array.isArray(_target) ? _target : [_target]).map(unrefElement).filter(notNullish);
  });
  let cleanup = noop;
  const isActive = ref(immediate);
  const stopWatch = isSupported.value ? watch(
    () => [targets.value, unrefElement(root), isActive.value],
    ([targets2, root2]) => {
      cleanup();
      if (!isActive.value)
        return;
      if (!targets2.length)
        return;
      const observer = new IntersectionObserver(
        callback,
        {
          root: unrefElement(root2),
          rootMargin,
          threshold
        }
      );
      targets2.forEach((el) => el && observer.observe(el));
      cleanup = () => {
        observer.disconnect();
        cleanup = noop;
      };
    },
    { immediate, flush: "post" }
  ) : noop;
  const stop = () => {
    cleanup();
    stopWatch();
    isActive.value = false;
  };
  tryOnScopeDispose(stop);
  return {
    isSupported,
    isActive,
    pause() {
      cleanup();
      isActive.value = false;
    },
    resume() {
      isActive.value = true;
    },
    stop
  };
}
function useElementVisibility(element, { window: window2 = defaultWindow, scrollTarget } = {}) {
  const elementIsVisible = ref(false);
  useIntersectionObserver(
    element,
    ([{ isIntersecting }]) => {
      elementIsVisible.value = isIntersecting;
    },
    {
      root: scrollTarget,
      window: window2
    }
  );
  return elementIsVisible;
}
const _sfc_main$b = {
  __name: "DropDownList",
  __ssrInlineRender: true,
  props: {
    list: Array
  },
  emits: ["itemClick"],
  setup(__props, { emit }) {
    const props = __props;
    const buttonRef = ref();
    let isButtonHover = useElementHover(buttonRef);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-center" }, _attrs))}><div class="relative inline-block"><div class="relative z-10 flex items-center text-sm text-gray-600 bg-white border border-transparent rounded-md focus:border-blue-500 focus:ring-opacity-40 focus:ring-blue-300 dark:focus:ring-blue-400 focus:ring focus:outline-none">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      _push(`<svg class="w-5 h-5 mx-1" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 15.713L18.01 9.70299L16.597 8.28799L12 12.888L7.40399 8.28799L5.98999 9.70199L12 15.713Z" fill="currentColor"></path></svg>`);
      if (unref(isButtonHover)) {
        _push(`<div class="absolute top-6 right-0 pt-2 z-40"><div class="z-20 p-2 overflow-hidden bg-white rounded-md shadow-xl w-[450px] flex flex-wrap"><!--[-->`);
        ssrRenderList(props.list, (item) => {
          _push(`<div${ssrRenderAttr("title", item.name)} href="#" class="w-24 p-2 text-center overflow-hidden justify-center text-ellipsis whitespace-nowrap items-center text-xl text-gray-600 transition-colors duration-200 transform hover:bg-gray-100">${ssrInterpolate(item.name)}</div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$b = _sfc_main$b.setup;
_sfc_main$b.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/DropDownList.vue");
  return _sfc_setup$b ? _sfc_setup$b(props, ctx) : void 0;
};
const DropDownList = _sfc_main$b;
const _sfc_main$a = {
  __name: "StrongTitle",
  __ssrInlineRender: true,
  props: {
    id: String,
    name: String,
    isCurrent: Boolean
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-fit cursor-pointer ph:mr-1" }, _attrs))} data-v-b2a4c4b5><div class="${ssrRenderClass(`font-trsFontFace text-2xl ph:text-xl px-1 break-keep ${props.isCurrent ? "font-extrabold" : "font-light"}`)}" data-v-b2a4c4b5>${ssrInterpolate(props.name)}</div><div class="${ssrRenderClass(`w-fit ${props.isCurrent ? "isActiveTab font-extrabold" : ""}`)}" data-v-b2a4c4b5></div></div>`);
    };
  }
};
const _sfc_setup$a = _sfc_main$a.setup;
_sfc_main$a.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StrongTitle.vue");
  return _sfc_setup$a ? _sfc_setup$a(props, ctx) : void 0;
};
const StrongTitle = /* @__PURE__ */ _export_sfc(_sfc_main$a, [["__scopeId", "data-v-b2a4c4b5"]]);
const useApiFetch = (request, opts) => {
  const config = /* @__PURE__ */ useRuntimeConfig();
  return useFetch(request, {
    // baseURL: !false ? `http://localhost:3000${config.public.baseURL}` : `https://www.xkb.com.cn${config.public.baseURL}`,
    baseURL: `https://www.xkb.com.cn${config.public.baseURL}`,
    // baseURL: `${config.public.baseURL}`,
    // suspense: true,
    server: true,
    headers: {
      "siteId": 35
    },
    ...opts
  }, "$5hFx8z1oTU");
};
const getAssetsFile = (url) => {
  console.log("111", new URL(`./assets/images/${url}.png`, globalThis._importMeta_.url).href, url);
  return new URL(`~/assets/images/${url}.png`, globalThis._importMeta_.url).href;
};
const replaceImgPath = (str) => {
  const reg = new RegExp("_600");
  return str.replace(reg, "");
};
const timeFormat = (dateStr) => {
  if (!dateStr) {
    return "";
  }
  const date = new Date(timeStringHandler(dateStr));
  const year = date.getFullYear();
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const dateString = `${year}-${month}-${day}`;
  const regEx = /^\d{4}-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01])$/;
  if (regEx.test(dateString)) {
    return dateString;
  } else {
    return "";
  }
};
const timeStringHandler = (timeStr) => {
  var regex = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})/;
  var resArr = regex.exec(timeStr);
  if (Array.isArray(resArr) && resArr.length) {
    var year = resArr[1], month = resArr[2], day = resArr[3], hour = resArr[4], minute = resArr[5], second = resArr[6];
    var newT = year + "/" + month + "/" + day + "\xA0" + hour + ":" + minute + ":" + second;
    newT = new Date(newT).getTime() + 8 * 3600 * 1e3;
    return newT;
  }
  return timeStr;
};
const jump = (data, router, flag) => {
  const { metaInfo } = data;
  let params = {};
  let path = "";
  if (metaInfo.docType === 8) {
    window.open(metaInfo.linkDoc, "_blank");
    return;
  }
  if (metaInfo.docType === 4) {
    window.open(metaInfo.linkDoc, "_blank");
    return;
  }
  if (metaInfo.docType === 3) {
    path = "special";
    const { docId } = data;
    params = {
      // groupid,
      docid: docId
    };
    const herf = router.resolve({
      name: path,
      query: params
    });
    if (flag.value) {
      window.open(herf.href, "_blank");
    } else {
      window.location.href = `https://www.xkb.com.cn/fundhtml/#/specialdoc?id=${data.id}`;
    }
  } else {
    path = "detail";
    params = {
      id: data.id || data.docId
    };
    const herf = router.resolve({
      name: path,
      query: params
    });
    if (flag.value) {
      window.open(herf.href, "_blank");
    } else {
      window.location.href = `https://www.xkb.com.cn/fundhtml/#/details?id=${data.id}`;
    }
  }
};
function splitAndMergeArray(arr, len, index) {
  const firstHalf = arr.slice(0, len);
  const secondHalf = arr.slice(len);
  if (index < len) {
    return firstHalf.concat(secondHalf);
  } else {
    const lastItem = firstHalf.pop();
    const indexInSecondHalf = index - len;
    if (indexInSecondHalf < secondHalf.length) {
      secondHalf[indexInSecondHalf] = lastItem;
    }
    firstHalf.push(arr[index]);
    return firstHalf.concat(secondHalf);
  }
}
const util = {
  getAssetsFile,
  timeFormat,
  jump,
  replaceImgPath,
  splitAndMergeArray
};
const axiosReqres = axios().provide.axios;
const channelStore = createStore({
  state: {
    channelListRaw: {
      loading: false,
      data: []
    },
    channelList: {
      loading: false,
      data: []
    },
    currentChannelId: "",
    currentGroupId: "",
    currentDocId: "",
    articleList: {
      loading: false,
      data: []
    },
    articleDetail: {},
    articleContent: {},
    featuresList: [],
    commentList: [],
    page: {
      current: 0,
      size: 20,
      keyword: ""
    },
    articleListOver: false,
    carouselList: [],
    recommendList: [],
    temp: []
  },
  actions: {
    async getRecommendList({ state, commit }) {
      const id = state.channelList.data.filter((i) => i.title === "\u9996\u9875")[0].id;
      const { data } = await axiosReqres(
        `/channels/getChildId?channelId=${id}`
      );
      const channelId = data.data.find((i) => i.title === "\u70ED\u95FB\u63A8\u8350").id;
      const list = await axiosReqres("/articles", {
        params: {
          chnlId: channelId,
          //区分不同web和客户端参数，固定
          visibility: 1,
          page: 0,
          size: 3
        }
      });
      try {
        commit("RECOMMEND", list.data.data);
      } catch (err) {
        throw err;
      }
    },
    async getCommentList({ state, commit }, id) {
      const list = await axiosReqres(
        // `/fundapis/comment/api/comments/article/191165/exemption`,
        `/fundapis/comment/api/comments/article/${id}/exemption`,
        {
          baseURL: ""
        }
      );
      try {
        commit("COMMENT", list);
      } catch (err) {
        throw err;
      }
    },
    async searchArticleList({ state, commit }, text) {
      state.page.keyword = text;
      const articles = await axiosReqres("/articles", {
        params: {
          //区分不同web和客户端参数，固定
          visibility: 1,
          page: state.page.current,
          size: state.page.size,
          keyword: state.page.keyword
        }
      });
      try {
        commit("CLEAR_ARTICLES");
        commit("ARTICLES", articles.data.data);
      } catch (err) {
        throw err;
      }
    },
    async searchArticleListAdd({ state, commit }) {
      const articles = await axiosReqres("/articles", {
        params: {
          //区分不同web和客户端参数，固定
          visibility: 1,
          page: state.page.current,
          size: state.page.size,
          keyword: state.page.keyword
        }
      });
      try {
        commit("ARTICLES", articles);
      } catch (err) {
        throw err;
      }
    },
    async setCurrentDocId({ commit }, id) {
      try {
        commit("CURRENT_DOC_ID", id);
      } catch (err) {
        throw err;
      }
    },
    async setCurrentGroupId({ commit }, id) {
      try {
        commit("CURRENT_GROUP_ID", id);
        commit("CLEAR_ARTICLES");
      } catch (err) {
        throw err;
      }
    },
    async clearArticleList({ commit }) {
      try {
        commit("CLEAR_ARTICLES");
      } catch (err) {
        throw err;
      }
    },
    async getSpecialList({ state, commit }, param) {
      const data = state.articleDetail.metaInfo.specialDoc.groups.find(
        (i) => i.groupId === state.currentGroupId
      ).docList;
      try {
        commit("SPECIAL_LIST", data);
      } catch (err) {
        throw err;
      }
    },
    async getArticleContent({ commit }, url) {
      const data = await axiosReqres(url);
      try {
        commit("ARTICLE_CONTENT", data);
      } catch (err) {
        throw err;
      }
    },
    async getArticleDetails({ commit }, id) {
      debugger;
      const data = await axiosReqres(`/getArticle/${id}`, {});
      debugger;
      try {
        commit("ARTICLE_DETAILS", data);
      } catch (err) {
        throw err;
      }
    },
    async getCarousel({ commit }, id) {
      const { data } = await useApiFetch("/articles/getRotationArticles", {
        params: {
          chnlId: id
        }
      });
      try {
        commit("CAROUSEL", data._rawValue.data);
      } catch (err) {
        throw err;
      }
    },
    async addPage({ commit }) {
      try {
        commit("ADD_PAGE");
      } catch (e) {
        throw e;
      }
    },
    async getChannel({ state, commit }, id = void 0) {
      const { data: allChannel } = await useApiFetch("/channels/getChildId", {
        params: {
          channelId: 348,
          size: 100
        }
      });
      debugger;
      state.temp = [...allChannel._rawValue.data];
    },
    async getChannelAdd({ state, commit }, id) {
      const { data: addChannel } = await useApiFetch("/channels/getChildId", {
        params: {
          channelId: 382,
          size: 100
        }
      });
      debugger;
      const finalData = [...state.temp, ...addChannel._rawValue.data];
      try {
        commit("CHANNEL", { channel: finalData, id });
      } catch (err) {
        throw err;
      }
    },
    async setCurrentId({ state, commit }, id) {
      state.page.keyword = "";
      try {
        commit("CURRENT_ID", id);
        commit("CLEAR_ARTICLES");
      } catch (err) {
        throw err;
      }
    },
    async getArticleList({ state, commit }, id) {
      const articles = await useApiFetch("/articles", {
        params: {
          chnlId: id || state.currentChannelId,
          //区分不同web和客户端参数，固定
          visibility: 1,
          page: state.page.current,
          size: id ? 10 : state.page.size,
          keyword: id ? "" : state.page.keyword
        }
      });
      try {
        id ? commit("FEATURES", articles.data._rawValue.data) : commit("ARTICLES", articles.data._rawValue.data);
      } catch (err) {
        throw err;
      }
    },
    async exchangeItem({ commit }, params) {
      try {
        commit("EXCHANGE_ITEM", params);
      } catch (err) {
        throw err;
      }
    }
  },
  mutations: {
    RECOMMEND: (state, data) => {
      state.recommendList = data;
    },
    COMMENT: (state, data) => {
      state.commentList = data.data.data;
    },
    CURRENT_DOC_ID: (state, id) => {
      state.currentDocId = id;
    },
    CURRENT_GROUP_ID: (state, id) => {
      state.currentGroupId = id;
    },
    // CLEAR_SPECIAL_ARTICLES: (state) => {
    //   state.articleList.data = [];
    //   state.page.current = 0;
    // },
    SPECIAL_LIST: (state, articles) => {
      state.articleList.data = articles.map((i) => {
        return {
          ...i,
          metaInfo: {
            ...i
          }
        };
      });
    },
    ARTICLE_CONTENT: (state, data) => {
      state.articleContent = data;
    },
    ARTICLE_DETAILS: (state, data) => {
      state.articleDetail = data.data.data;
    },
    CAROUSEL: (state, carousel) => {
      state.carouselList = carousel;
    },
    CHANNEL: (state, { channel, id }) => {
      state.channelListRaw.data = [...channel];
      const filterData = channel.filter(
        (i) => i.defaultPosition === 1 || i.defaultPosition === 2
      );
      state.channelList.data = state.currentChannelId ? state.channelList.data : filterData;
      if (id) {
        const index = state.channelList.data.findIndex((i) => i.id === id);
        state.channelList.data = util.splitAndMergeArray(
          state.channelList.data,
          7,
          index
        );
        state.currentChannelId = id;
        return;
      }
      if (state.channelList.data.length) {
        state.currentChannelId = state.currentChannelId || state.channelList.data[0].id;
      }
    },
    CURRENT_ID: (state, id) => {
      state.currentChannelId = id;
    },
    ARTICLES: (state, articles) => {
      state.articleList.loading = false;
      state.articleListOver = articles.length < 10 ? true : false;
      state.articleList.data = [
        ...state.articleList.data,
        ...articles
      ];
    },
    CLEAR_ARTICLES: (state) => {
      state.articleList.data = [];
      state.page.current = 0;
    },
    ADD_PAGE: (state) => {
      state.page.current += 1;
    },
    FEATURES: (state, articles) => {
      state.featuresList = articles;
    },
    EXCHANGE_ITEM: (state, params) => {
      const { index, data } = params;
      const dataIndex = state.channelList.data.findIndex(
        (i) => i.id === data.id
      );
      const temp = state.channelList.data[index - 1];
      state.channelList.data[index - 1] = state.channelList.data[dataIndex];
      state.channelList.data[dataIndex] = temp;
      state.channelList.data = [...state.channelList.data];
    }
  }
});
const DEFAULT_KEY = "showmore";
const DEFAULT_LIST_LENGTH = 7;
const _sfc_main$9 = {
  __name: "CustomTabs",
  __ssrInlineRender: true,
  props: {
    isPc: Boolean
  },
  setup(__props) {
    const props = __props;
    const router = useRouter();
    useRoute();
    const { state } = channelStore;
    const tabList = ref([]);
    const showModal = ref(false);
    const el = ref(null);
    const divs = ref({});
    watch(() => state.channelList.data, () => {
      tabList.value = [...state.channelList.data.map((i) => {
        return {
          id: i.id,
          name: i.title
        };
      })];
    });
    const DEFAULT_LENGTH = computed(() => {
      return props.isPc ? DEFAULT_LIST_LENGTH : tabList.value.length;
    });
    watch(() => props.isPc, (value) => {
      DEFAULT_LENGTH.value = value ? DEFAULT_LIST_LENGTH : tabList.value.length;
      tabList.value = [...tabList.value];
    });
    const currentId = ref("");
    watch(() => state.currentChannelId, (value) => {
      currentId.value = value;
      if (!props.isPc) {
        console.log(currentId.value);
        nextTick(() => {
          var _a, _b;
          (_b = (_a = divs.value) == null ? void 0 : _a[currentId.value]) == null ? void 0 : _b.scrollIntoView({ inline: "start" });
        });
      }
    });
    const setCurrentId = (id) => {
      switchShowModal("close");
      channelStore.dispatch("setCurrentId", id).then(() => {
        var _a, _b;
        window.scrollTo(0, 0);
        if (!props.isPc) {
          (_b = (_a = divs.value) == null ? void 0 : _a[currentId.value]) == null ? void 0 : _b.scrollIntoView({ inline: "start" });
        }
        channelStore.dispatch("getArticleList");
      });
      router.push({ path: "/home", query: { id } });
    };
    const showList = computed(() => {
      return [...tabList.value.slice(0, DEFAULT_LENGTH.value), { id: DEFAULT_KEY, name: "\u66F4\u591A" }];
    });
    const hiddenList = computed(() => {
      if (tabList.value.length < DEFAULT_LENGTH.value) {
        return [];
      }
      return tabList.value.slice(DEFAULT_LENGTH.value);
    });
    const hiddenListClick = (data) => {
      channelStore.dispatch("exchangeItem", { index: DEFAULT_LENGTH.value, data });
      setCurrentId(data.id);
    };
    const switchShowModal = (close) => {
      if (close === "close") {
        showModal.value = false;
        return;
      } else {
        showModal.value = !showModal.value;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "w-full flex ph:overflow-x-auto justify-between scrollBar ph:pr-8",
        ref_key: "el",
        ref: el
      }, _attrs))} data-v-b459cde0><!--[-->`);
      ssrRenderList(showList.value, (item) => {
        _push(`<div${ssrRenderAttr("id", item.id)} class="flex justify-start" data-v-b459cde0>`);
        if (item.id !== DEFAULT_KEY) {
          _push(ssrRenderComponent(StrongTitle, {
            name: item.name,
            isCurrent: currentId.value === item.id,
            onClick: ($event) => setCurrentId(item.id)
          }, null, _parent));
        } else if (hiddenList.value.length && __props.isPc) {
          _push(`<div class="w-fit cursor-pointer" data-v-b459cde0>`);
          _push(ssrRenderComponent(DropDownList, {
            list: hiddenList.value,
            onItemClick: hiddenListClick
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="font-trsFontFace text-2xl px-1 break-keep font-light" data-v-b459cde0${_scopeId}>${ssrInterpolate(item.name)}</div>`);
              } else {
                return [
                  createVNode("div", { class: "font-trsFontFace text-2xl px-1 break-keep font-light" }, toDisplayString(item.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (!__props.isPc) {
        _push(`<div class="flex-1 right-0 top-[68px] bg-white ph:right-0 ph:absolute ph:top-[68px]" data-v-b459cde0>`);
        _push(ssrRenderComponent(unref(Bars3BottomRightIcon), { class: "h-7 ml-2" }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      if (showModal.value) {
        _push(`<div class="fixed left-0 h-[600px] w-full bg-white bottom-0 rounded-t-lg z-[120] p-3 shadow-xl" style="${ssrRenderStyle({ "box-shadow": "0 -6px 6px #c1c1c1" })}" data-v-b459cde0><div class="flex w-full justify-between mb-3" data-v-b459cde0>`);
        _push(ssrRenderComponent(StrongTitle, {
          name: `\u66F4\u591A\u680F\u76EE`,
          isCurrent: true
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u66F4\u591A\u680F\u76EE`);
            } else {
              return [
                createTextVNode("\u66F4\u591A\u680F\u76EE")
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(unref(XMarkIcon), {
          class: "w-5 h-5",
          onClick: ($event) => switchShowModal("close")
        }, null, _parent));
        _push(`</div><div class="w-full h-[550px] flex justify-start flex-wrap overflow-y-scroll items-start" data-v-b459cde0><!--[-->`);
        ssrRenderList(showList.value.filter((i) => i.name !== "\u66F4\u591A"), (item) => {
          _push(`<div${ssrRenderAttr("title", item.name)} href="#" class="min-w-[100px] p-2 text-center h-11 mr-3 mb-2 bg-slate-200 overflow-hidden justify-center text-ellipsis whitespace-nowrap items-center text-xl transition-colors duration-200 transform hover:bg-gray-100" data-v-b459cde0>${ssrInterpolate(item.name)}</div>`);
        });
        _push(`<!--]--></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$9 = _sfc_main$9.setup;
_sfc_main$9.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CustomTabs.vue");
  return _sfc_setup$9 ? _sfc_setup$9(props, ctx) : void 0;
};
const CustomTabs = /* @__PURE__ */ _export_sfc(_sfc_main$9, [["__scopeId", "data-v-b459cde0"]]);
const _sfc_main$8 = {
  __name: "InfoBar",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-start text-gray-500" }, _attrs))}><div class="mr-4">${ssrInterpolate(__props.data.source || "\u65B0\u5FEB\u62A5")}</div><div class="mr-4">${ssrInterpolate(unref(util).timeFormat(__props.data.time))}</div></div>`);
    };
  }
};
const _sfc_setup$8 = _sfc_main$8.setup;
_sfc_main$8.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/InfoBar.vue");
  return _sfc_setup$8 ? _sfc_setup$8(props, ctx) : void 0;
};
const InfoBar = _sfc_main$8;
const _sfc_main$7 = {
  __name: "NewsItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const formatTitle = (str) => {
      if (str.length > 45) {
        return str.slice(0, 45) + "...";
      } else {
        return str;
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: `w-full flex justify-between min-h-32 pb-4 border-b-[1px] border-gray-300 ph:text-sm` }, _attrs))}><div class="flex flex-col justify-between"><div class="text-xl font-medium cursor-pointer mr-3 ph:overflow-ellipsis hover:text-primary ph:max-h-28 ph:max-w-[240px] ph:text-lg">${ssrInterpolate(isPc.value ? props.data.listTitle : formatTitle(props.data.listTitle))}</div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: (_b = (_a = props.data) == null ? void 0 : _a.metaInfo) == null ? void 0 : _b.source, comment: (_c = props == null ? void 0 : props.data) == null ? void 0 : _c.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
      if (props.data.metaInfo.listStyle !== 2) {
        _push(`<img${ssrRenderAttrs(mergeProps({ class: "h-full ph:w-28 w-44 rounded-lg object-cover" }, ssrGetDirectiveProps(_ctx, _directive_lazy, props.data.metaInfo.thumbnails[0])))}>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$7 = _sfc_main$7.setup;
_sfc_main$7.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NewsItem.vue");
  return _sfc_setup$7 ? _sfc_setup$7(props, ctx) : void 0;
};
const NewsItem = _sfc_main$7;
const _sfc_main$6 = {
  __name: "ImageListItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><div class="text-xl font-medium cursor-pointer ph:text-lg hover:text-primary">${ssrInterpolate(props.data.listTitle)}</div><div class="w-full flex"><!--[-->`);
      ssrRenderList(props.data.metaInfo.thumbnails, (item) => {
        _push(`<div class="w-full px-2 py-1"><img${ssrRenderAttrs(mergeProps({
          alt: item,
          class: "w-full h-44 ph:h-20 object-cover rounded-lg"
        }, ssrGetDirectiveProps(_ctx, _directive_lazy, item)))}></div>`);
      });
      _push(`<!--]--></div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: props.data.metaInfo.source, comment: props.data.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/ImageListItem.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const ImageListItem = _sfc_main$6;
const _sfc_main$5 = {
  __name: "NarrowImage",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _directive_lazy = resolveDirective("lazy");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full" }, _attrs))}><img${ssrRenderAttrs(mergeProps({ class: "w-full rounded-xl" }, ssrGetDirectiveProps(_ctx, _directive_lazy, unref(util).replaceImgPath(props.data.metaInfo.thumbnails[0]))))}></div>`);
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NarrowImage.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const NarrowImage = _sfc_main$5;
const _sfc_main$4 = {
  __name: "NewsItemDetail",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: `w-full flex justify-between min-h-32 pb-4 border-b-[1px] border-gray-300` }, _attrs))}><div class="flex flex-col justify-between"><div class="text-xl font-medium cursor-pointer hover:text-primary">${ssrInterpolate(props.data.listTitle)}</div>`);
      _push(ssrRenderComponent(InfoBar, {
        data: { source: props.data.source, comment: props.data.commentCount, time: props.data.docPubTime }
      }, null, _parent));
      _push(`</div>`);
      if (props.data.listStyle !== 2) {
        _push(`<img${ssrRenderAttr("src", props.data.thumbnails[0])} class="h-full w-44 rounded-lg object-cover">`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/NewsItemDetail.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const NewsItemDetail = _sfc_main$4;
const _sfc_main$3 = {
  __name: "ListItem",
  __ssrInlineRender: true,
  props: {
    data: {
      type: Object
    },
    plainData: {
      type: Object
    }
  },
  setup(__props) {
    const props = __props;
    const componentsList = {
      0: props.data ? NewsItem : NewsItemDetail,
      1: ImageListItem,
      3: NewsItem,
      2: NewsItem,
      4: NarrowImage
    };
    const key = props.data ? props.data.metaInfo.listStyle : props.plainData.listStyle;
    const finalData = props.data ? props.data : props.plainData;
    return (_ctx, _push, _parent, _attrs) => {
      ssrRenderVNode(_push, createVNode(resolveDynamicComponent(componentsList[unref(key)]), mergeProps({
        data: unref(finalData),
        class: "mb-6"
      }, _attrs), null), _parent);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/ListItem.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const ListItem = _sfc_main$3;
const _imports_2 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABMAAAATCAYAAAByUDbMAAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAEaSURBVDiNrdQxTsMwFAbg/0VcAMmtegIsMVVcAHMBku70CBUTc9O5Y9eKJd3TnKCWuACru7EhEglOULNg1Ch+doJ4o1/y+fk9J4SfMJnIYbEEAAL0VdXcYWAQAJhUWF9SVg0NwZJjKg5c0mQiH1QZV5ULWTU0KUp1AhQAfMxn7AYXIeh1JDHebe3pbG2029/WD5m3n0kIWqinzjoBalKUqjfGQS7ckaNYDAL4vnWwGARrV1yqhT1f30ehP0+z5QC6DkCdym5qwz5IgBoXZX9sWhtMAyCIliGwM4CNXkfB3lgfkL+0BO+oN3oN+fn25cu9z2fai8l9k3MVvCweLy3QfjFwz37/V8dUHKz7TAir801c0xNAc1X9e3wDac9mu/xxGCQAAAAASUVORK5CYII=";
const _imports_1 = "" + buildAssetsURL("ygaba.5c590e6b.png");
const _sfc_main$2 = {
  __name: "SideBar",
  __ssrInlineRender: true,
  setup(__props) {
    axios().provide.axios;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    ref(breakpoints.greater("md"));
    useRouter();
    const featuresList = ref([]);
    const requestData = async () => {
      const { data } = await useApiFetch("/articles?chnlId=430&visibility=1&page=0&size=10");
      featuresList.value = data._rawValue.data;
    };
    requestData();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[--><div class="flex flex-col">`);
      _push(ssrRenderComponent(StrongTitle, {
        name: "\u8F7B\u62A5\u7EB8",
        isCurrent: true,
        class: "mb-3"
      }, null, _parent));
      _push(`<a href="https://epaper.xkb.com.cn/" target="_blank"><img src="https://epaper.xkb.com.cn/index.php?s=/index/firstedition/" class="w-full h-full rounded-lg"></a></div><div class="flex flex-col sticky top-[80px] bg-white">`);
      _push(ssrRenderComponent(StrongTitle, {
        name: "\u4E13\u9898",
        isCurrent: true,
        class: "mb-3 mt-4"
      }, null, _parent));
      _push(`<div class="bg-teal-50 rounded-xl p-3"><!--[-->`);
      ssrRenderList(featuresList.value, (item) => {
        _push(`<div class="mr-4 flex items-center mb-2 cursor-pointer"><img${ssrRenderAttr("src", _imports_2)} class="h-3 w-3"><a>${ssrInterpolate(item.title)}</a></div>`);
      });
      _push(`<!--]--></div><div class="full flex items-start ph:px-1 ph:py-3 flex-col text-sm mt-2 text-gray-400"><div><a class="active:text-yellow-400 hover:text-yellow-400" href="https://beian.miit.gov.cn/#/Integrated/index" target="_blank">\u7CA4ICP\u590710220059\u53F7 </a></div><div class="flex items-center"><img class="w-4"${ssrRenderAttr("src", _imports_1)} alt=""><a class="active:text-yellow-400 hover:text-yellow-400" href="https://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44010602008415" target="_blank">\u7CA4\u516C\u7F51\u5B89\u5907 44010602008415\u53F7 </a></div></div></div><div></div><!--]-->`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SideBar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const SideBar = _sfc_main$2;
const _imports_0$1 = "" + buildAssetsURL("miniLogo.ebb38594.png");
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    useRouter();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "full flex flex-col" }, _attrs))}><div class="full h-12 bg-primary text-white flex justify-between items-center px-8 ph:px-1 ph:text-sm"><div class="flex items-center"><img class="h-8 mr-4"${ssrRenderAttr("src", _imports_0$1)} alt=""><div> \u7248\u6743\u6240\u6709 \xA9 \u5E7F\u4E1C\u65B0\u5FEB\u62A5\u793E \u4E3E\u62A5\u53CA\u6295\u8BC9\u7535\u8BDD\uFF1A020 87133906</div></div><div class="cursor-pointer active:text-yellow-400 hover:text-yellow-400 ph:hidden"> \u5173\u4E8E\u6211\u4EEC </div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Footer = _sfc_main$1;
const _imports_0 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADiZJREFUeF7tnWuMJGUVhs/p3SBBfygJJpJs19dTjTExAQkJ+kMSVgLeojEiOxMjEbwRTAjekOgShYgbFC/EBIMYVoMxJgiiiAIGBFFBRRSQXRT7UtWDwO6iIBcXha1jeqYV2N3uPvX1qW+qut75O+85p77n1EMtne5pJvyAAAiMJcBgAwIgMJ4ABMHdAQITCEAQ3B4gAEFwD4CAHwE8Qfy4oaomBCBITRaNY/oRgCB+3FBVEwIQpCaLxjH9CEAQP26oqgkBCFKTReOYfgQgiB83VNWEAASpyaJxTD8CEMSPG6pqQgCC1GTROKYfAQjixw1VNSEAQWqyaBzTjwAE8eOGqpoQgCA1WTSO6UcAgvhxQ1VNCECQmiwax/QjAEH8uKGqJgQgSE0WjWP6EYAgftxQVRMCEKQmi8Yx/QgUJkir1Tp6nchxmfCrmSQW4m1+l4gqEHiOAFMWkXCXiO98lrNr0zR9qEg+5oK0W60TROQcEjqmyAtHbxBYJSDfpPXrz+l2uzuLIGIqyIJzp7LQ1iIuFD1BYAKBh/cwHZkkycPWlMwEcc4duE5ot/UFoh8IaAgI8WW9tP8BTTZPxkyQhaY7k5kuyjMcWRAwJfDMumb3we6yZU8zQdqRu0uIjrC8OPQCgTwEhOn0XpJckqdmWtZMkDiKniDil0wbiN+DQFEEivhnlp0gTXc/MR1W1OHRFwSmEWCSzZ003TItl+f3ZoK0nbtAhM7OMxxZELAkIFnj6N5y7w7LnmaCvNK5V+0Rus/y4tALBHIQuLmbJm/IkVdFzQQZTouj6ItEfJZqMkIgYEiAmTZ2kuQWw5YrrUwFWZWkdT6RbLa+UPQDgf0SEHlSmE7ppelVRRAyF2R4ka1WK2pkdDKLvC1jajPRwXtdfKHvnykCFHquKYFX7DV9wMR3iNA13UH/8iKvrBBBirxg9AaBkAQgSEjamFU5AhCkcivDBYckAEFC0sasyhGAIJVbGS44JAEIEpI2ZlWOAASp3MpwwSEJQJCQtDGrcgQgSOVWhgsOSQCChKSNWZUjAEEqtzJccEgCECQkbcyqHAEIUrmV4YJDEoAgIWljVuUIQJA1XFm72TpJGnIGCW0gIkckDwjR7SS8vXHA+q90Op3H1/DyMLqID0yBqo5AO3JbhejUCeltLHxeZ9D/vq4jUkUQwBOkCKpTesZR9Esifr1mNAtvgiQaUsVkIEgxXMd2jSP3cyLamGcsJMlDyzYLQWx5TuwWR60bieQ4n5GQxIfa7DUQZHaGqg4Lzt3AQieowmNCkGQWen61EMSPW66qOHLXEdGbchVBEgtcM/eAIDMjnNwgjlrXEslbLcfgSWJJc3IvCFIg69i5H5HQ24sYAUmKoLpvTwhSEOc4clcT0TsKar/SFpIUSXe1NwQpgHE7al0pJCcW0HqflpCkWMoQxJjvQhRdwcQnGbed2A6SFEcbghiyjSP3PSJaMmypbgVJ1KhyBSFILlzjw+3IfVeI3m3UzqsNJPHCNvnpbN+yfh3jKLqciE8uw8khie0W8ASZkWfcdN8iplNmbGNaDknscEKQGVi2I3eZEL1vhhaFlUISG7QQxJNjHEWXEvEHPcuDlEGS2TFDEA+GcdNdQkyneZQGL4EksyGHIDn5LUSti5nkwznL1jQOSfzxQ5Ac7OIo+hoRn5GjpDRRSOK3Cgii5BY33UXEdKYyXsoYJMm/FgiiYLYQtb7MJB9TREsfgST5VgRBpvCKo+hCIv5EPqxj0+L5BtHh938fa3QNeBdwDpAQZAKstnMXiNDZOXhOimYsvCQsV3j0u0VIdlm+CRJPEt0WIMgYTgtNt4WZPqXDODW1ZygHNeQREbp5anrfwC3dNNlo/U5hSDJ9ExBkP4ziKPocEZ8zHZ8mIc8K0VIvTa9qO3fsLIIMp0ESDXO7DATZi2XbuXNF6LNGiJ8RkqEcPxj2sxAEkhhtRtkGgjwP1ELTnctsJsd/iGSpm6bDj96u/FgJAkmUd7dBDIKMIBrL8W9iWuomyQ+fvyNLQSCJwd2vaAFBhv+ut31yPM0NXuz0+9fszd9aEEiiuMNnjNReEGM5drPwYmfQ//H+9lKEIJBkRgOmlNdaEEs5mOipTBpLvUHv2nHMixIEkhQnSW0FsZSDiJ8UyoavVv1k0qqKFASSFCNJLQWxlYOeGL2U+9NpKypaEEgybQP5f187QYzleHz0Uu7wj1NP/QkhCCSZuoZcgVoJYizHP0cv5V6vJR5KEEii3cj0XG0EMZbjMWZa6iTJDdMRP5cIKQgkybOZ8dlaCGIsx6Oc8VJnuf+zvCsILQgkybuhffNzL4ilHEz0j0wai71B70Yf9GshCCTx2dRzNXMtiKUcRPR3kWyxNxjc5It8rQSBJL4bm+OvP7CVQx4hosVumg6/odb7Zy0FgSR+a5vLJ4itHLSLSIZy+HzQ6QVbWWtBIEl+SeZOEGM5djLTYidJhp8Jn/mnDIJAknxrnCtBjOXYMZLjF/mQjk+XRRBIot/o3AhiLMdDWcZL/eX+rXqU05NlEgSSTN/XMDEXghjL8aCsvpT7Kx1CfapsgkCS6burvCDGcvyNJFvsDga/no4uf6KMgkCSyXustCC2cvADRNnw1arb8t/6uoqyCgJJxu+vsoKYyiG0zCyLnTS9XXer+6XKLAgk2f9OKymIqRxEg9GrVb/xu+31VWUXZHgS62/qrfofp6ucIMZypA2mxb8myW/1t7l/sgqCrD5JWt9hkvf4n/SFlVWWpFKCGMuRZA1e7Pf7v7O6Eab1qYogK0+Spvs2Mb132pm0v6+qJJURJI6iNxPx1I+1ahYmRH3KGpt6y73fa/JWmSoJsvokcZex2ZeUyr0vfvrp192zY8dTVjxD9KmOIM7dSkLHGEDpkWSbuoPBnQa9crWomiArTxLnvkFCH8p10DFhJtncSdMtFr1C9aiEIK1W6/BGJncbQOkyyaZOmv7BoFfuFlUUZHjIduS+LkSn5z7w3gVMf+omyeEz9wnYoBKCtJutk4Xl8tm4SIeJhnL8cbY+/tVVFWTlSWL0/YzPSHbwYDB41J9i2MpKCBJH0ceJ+EszoLl/9GrVXTP0mLm0yoKsPEma7qvC9JFZQDDTRqt3R89yHdraSgjSaraOb7Dk/gz4CMJfRq9WWfwTTct1v7mqC7L6JGldSCTeX0m3h+llSZI8NhPIgMWVECSO4w307J5BXi5M9Oc9qy/l3pO3toj8PAiy8iTx/Go6IbqrlyZHFsG2qJ6VEGT1fxRbVwrJiTlA3EfZuk3d5e69OWoKjc6LIKMnyeeJ5NN5gAnTR3tJclGemrXOVkYQ59yB64R2K4FtZ8k2dQaDbcp8kNg8CTJ6kpwnQp/RwGPiqzpp/12abJkylRFkCO0w516TrX4J5ksnQLyNSM7vpqnqz4GGXMa8CTJkp3p3A9Ol3SQ5LSRrq1mVEuR/hx77kqPQJS/a/dRZ23ftetIKkGWfeRRk9CQZfjnp8Hsd9/kudyF5fy9Nt1pyDNmrkoKsLGXDhlgajcNF+AhmuZuz7J7O8nI3JLy8s+ZVkP//h6vZPIqocRSzrCfm7bR+/bZOp7MrL6cy5SsrSJkgaq9l3gXRcqhSDoIE3BYECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatpAEA2lcmUgSMB9QJCAsI1GQRAjkJo2EERDqVwZCBJwHxAkIGyjURDECKSmDQTRUCpXBoIE3AcECQjbaBQEMQKpaQNBNJTKlYEgAfcBQQLCNhoFQYxAatvEkdtJRIdo88OcCJ3XGyTn5qlB1oYABLHhqO7SjtxWITpVXbASlHd20/TqfDVIWxCAIBYUc/RoO/dGEbo+R8l13TR5S448ooYEIIghTG2ruOk+SUxf0OS7aYIdaUAVlAH8gsBOaxs3m0cJNy5motfuL8skmztpumVaH/y+WAIQpFi+E7sfeuihBx10wAHHS8YvZ84OyZj/RSI7SWRHbzC4aQ0vDaNHBCAIbgUQmEAAguD2AAEIgnsABPwI4Anixw1VNSEAQWqyaBzTjwAE8eOGqpoQgCA1WTSO6UcAgvhxQ1VNCECQmiwax/QjAEH8uKGqJgQgSE0WjWP6EYAgftxQVRMCEKQmi8Yx/QhAED9uqKoJAQhSk0XjmH4EIIgfN1TVhAAEqcmicUw/AhDEjxuqakIAgtRk0TimHwEI4scNVTUhAEFqsmgc048ABPHjhqqaEIAgNVk0julHAIL4cUNVTQhAkJosGsf0I/BfRlcOI+9Hku4AAAAASUVORK5CYII=";
const _sfc_main = {
  __name: "ScrollToTop",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "fixed right-24 bottom-32 ph:right-4 ph:bottom-6 rounded-2xl flex flex-col justify-center items-center shadow-xl p-3 cursor-pointer bg-white z-[100] active:bg-primary" }, _attrs))}><img class="w-8 h-8 ph:w-4 ph:h-4"${ssrRenderAttr("src", _imports_0)} alt=""><div class="text-xs ph:hidden">\u56DE\u5230\u9876\u90E8</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ScrollToTop.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const ScrollToTop = _sfc_main;

export { CustomTabs as C, DropDownList as D, Footer as F, InfoBar as I, ListItem as L, StrongTitle as S, _imports_0$2 as _, useBreakpoints as a, util as b, channelStore as c, SideBar as d, ScrollToTop as e, breakpointsTailwind as f, useElementHover as g, useIntervalFn as h, _imports_2 as i, useElementVisibility as u };
//# sourceMappingURL=ScrollToTop-504779c7.mjs.map
