const index_vue_vue_type_style_index_0_scoped_09eb8f19_lang = ".mask[data-v-09eb8f19]{background:linear-gradient(180deg,transparent,rgba(3,47,50,.9));height:100%;opacity:1;position:absolute;width:100%}.container[data-v-09eb8f19]{overflow:hidden;white-space:nowrap;width:340px}.scroll-text[data-v-09eb8f19]{animation:scroll-09eb8f19 12s linear infinite;display:inline-block}@keyframes scroll-09eb8f19{0%{transform:translateX(20px)}to{transform:translateX(-100%)}}";

const indexStyles_b78ee429 = [index_vue_vue_type_style_index_0_scoped_09eb8f19_lang];

export { indexStyles_b78ee429 as default };
//# sourceMappingURL=index-styles.b78ee429.mjs.map
