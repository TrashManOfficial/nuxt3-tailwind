const Carousel_vue_vue_type_style_index_0_scoped_7288abfa_lang = ".opacityLinear[data-v-7288abfa]{background:linear-gradient(0deg,rgba(0,0,0,.7) 10%,rgba(0,0,0,.01))}";

const CarouselStyles_6b7eebb2 = [Carousel_vue_vue_type_style_index_0_scoped_7288abfa_lang];

export { CarouselStyles_6b7eebb2 as default };
//# sourceMappingURL=Carousel-styles.6b7eebb2.mjs.map
