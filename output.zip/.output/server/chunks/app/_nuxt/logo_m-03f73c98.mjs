import { b as buildAssetsURL } from '../../handlers/renderer.mjs';

const _imports_1 = "" + buildAssetsURL("logo_m.9890f935.png");

export { _imports_1 as _ };
//# sourceMappingURL=logo_m-03f73c98.mjs.map
