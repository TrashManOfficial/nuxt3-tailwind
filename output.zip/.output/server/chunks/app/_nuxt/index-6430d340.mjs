globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { ref, watch, withCtx, createVNode, unref, useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttr, ssrRenderComponent, ssrRenderList, ssrRenderAttrs, ssrRenderSlot, ssrInterpolate } from 'vue/server-renderer';
import { a as useBreakpoints, u as useElementVisibility, c as channelStore, _ as _imports_0$2, C as CustomTabs, L as ListItem, d as SideBar, e as ScrollToTop, F as Footer, f as breakpointsTailwind, b as util, g as useElementHover } from './ScrollToTop-504779c7.mjs';
import { _ as _imports_1 } from './logo_m-03f73c98.mjs';
import { S as SearchBar } from './SearchBar-2568e8c4.mjs';
import { useRoute, useRouter } from 'vue-router';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import '../server.mjs';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-devtools-stub';
import 'axios';
import 'vue3-lazyload';

const _imports_0 = "" + buildAssetsURL("ios.93d30a48.png");
const _sfc_main$1 = {
  __name: "DropDownModal",
  __ssrInlineRender: true,
  setup(__props) {
    const buttonRef = ref();
    let isButtonHover = useElementHover(buttonRef);
    const imglist = [
      {
        src: "~/assets/images/douyin_qrcode.png",
        name: "douyin_qrcode",
        alt: "\u6296\u97F3"
      },
      {
        src: "~/assets/images/sina_qrcode.png",
        name: "sina_qrcode",
        alt: "\u5FAE\u535A"
      },
      {
        src: "~/assets/images/wx_qrcode.png",
        name: "wx_qrcode",
        alt: "\u516C\u4F17\u53F7"
      }
    ];
    const generateImgPath = (fileName) => {
      return new URL(`../assets/images/${fileName}.png`, globalThis._importMeta_.url).href;
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex justify-center" }, _attrs))}><div class="relative inline-block"><div class="relative z-10 flex items-center border border-transparent rounded-md focus:border-blue-500 focus:ring-opacity-40 dark:focus:ring-opacity-40 focus:ring-blue-300 focus:ring focus:outline-none">`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      if (unref(isButtonHover)) {
        _push(`<div class="absolute top-9 right-0 p-2 z-40 flex bg-white w-[420px] justify-between rounded-lg"><!--[-->`);
        ssrRenderList(imglist, (item) => {
          _push(`<div class="flex flex-col items-center"><img class="w-20 h-20"${ssrRenderAttr("src", generateImgPath(item.name))}${ssrRenderAttr("alt", item.alt)}><div class="text-black text-sm">${ssrInterpolate(item.alt)}</div></div>`);
        });
        _push(`<!--]--><div class="flex flex-col items-center"><img class="w-20 h-20" src="https://app.xkb.com.cn/fundapis/uc/api/files/rc-upload-1672040423081-6" alt=""><div class="text-black text-sm">\u5B89\u5353\u4E0B\u8F7D</div></div><div class="flex flex-col items-center"><img class="w-20 h-20"${ssrRenderAttr("src", _imports_0)} alt=""><div class="text-black text-sm">ios\u4E0B\u8F7D</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/DropDownModal.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const DropDownModal = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const startRenderList = ref(false);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const bottomRef = ref();
    const tabRef = ref();
    const targetIsVisible = useElementVisibility(bottomRef);
    const tabIsVisible = useElementVisibility(tabRef);
    const Articlelist = ref([]);
    const { query } = useRoute();
    watch(() => channelStore.state.articleList.data, (value) => {
      Articlelist.value = [...value];
    });
    watch(targetIsVisible, (value) => {
      if (startRenderList.value && value && !channelStore.state.articleListOver) {
        channelStore.dispatch("addPage").then(() => {
          channelStore.dispatch("searchArticleListAdd").then(() => {
          });
        });
      }
    });
    const router = useRouter();
    const toDetail = (data) => {
      util.jump(data, router, isPc);
    };
    const onSearch = (text) => {
      channelStore.dispatch("searchArticleList", text).then(() => {
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (isPc.value) {
        _push(`<div class="w-full flex fixed top-0 bg-white h-20 items-center shadow-md z-50 justify-center"><div class="w-[1500px] flex"><div class="w-full flex items-center justify-between"><img class="m-2 h-12"${ssrRenderAttr("src", _imports_0$2)} alt="\u65B0\u5FEB\u7F51logo">`);
        _push(ssrRenderComponent(CustomTabs, {
          ref_key: "tabRef",
          ref: tabRef,
          class: "justify-around",
          isPc: isPc.value
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex flex-col items-center"><div class="w-full h-[320px] flex items-center flex-col bg-no-repeat bg-cover bg-searchBarBackground ph:bg-none ph:h-fit"><div class="text-lg text-white flex justify-end py-2 pr-6 w-full cursor-pointer ph:hidden">`);
      _push(ssrRenderComponent(DropDownModal, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="text-lg text-white flex justify-end py-2 pr-6 w-full cursor-pointer"${_scopeId}> \u5168\u5A92\u4F53\u77E9\u9635 </div>`);
          } else {
            return [
              createVNode("div", { class: "text-lg text-white flex justify-end py-2 pr-6 w-full cursor-pointer" }, " \u5168\u5A92\u4F53\u77E9\u9635 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="w-full h-full flex-1 flex items-center"><div class="h-16 w-full ph:h-14 ph:px-2 flex justify-center ph:justify-between ph:items-center ph:bg-primary"><img class="hidden ph:flex ph:h-8"${ssrRenderAttr("src", _imports_1)} alt="">`);
      _push(ssrRenderComponent(SearchBar, {
        onOnSearch: onSearch,
        data: unref(query).keyword,
        class: "w-1/2 ph:w-[250px]",
        ref_key: "tabRef",
        ref: tabRef
      }, null, _parent));
      _push(`</div></div></div><div class="w-[1100px] flex ph:w-full justify-center mt-5 ph:mt-3"><div class="w-9/12 ph:w-full ph:px-2 mr-6 ph:mr-0">`);
      if (Articlelist.value.length) {
        _push(`<div class="w-full"><!--[-->`);
        ssrRenderList(Articlelist.value, (item) => {
          _push(ssrRenderComponent(ListItem, {
            data: item,
            key: item,
            onClick: ($event) => toDetail(item)
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="w-3/12 ph:hidden pl-2">`);
      _push(ssrRenderComponent(SideBar, null, null, _parent));
      _push(`</div></div>`);
      if (!unref(tabIsVisible)) {
        _push(ssrRenderComponent(ScrollToTop, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full">`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/search/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-6430d340.mjs.map
