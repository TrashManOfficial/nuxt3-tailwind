import { H as Head, _ as __nuxt_component_1 } from './client-only-1859eae7.mjs';
import { useSSRContext, ref, withAsyncContext, watch, nextTick, withCtx, createVNode, toDisplayString, unref, mergeProps } from 'vue';
import { ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderClass, ssrRenderAttrs } from 'vue/server-renderer';
import { a as useBreakpoints, f as breakpointsTailwind, u as useElementVisibility, c as channelStore, _ as _imports_0$2, C as CustomTabs, i as _imports_2, L as ListItem, d as SideBar, e as ScrollToTop, F as Footer, g as useElementHover, h as useIntervalFn, b as util } from './ScrollToTop-504779c7.mjs';
import { _ as _imports_1 } from './logo_m-03f73c98.mjs';
import { S as SearchBar } from './SearchBar-2568e8c4.mjs';
import { useRoute, useRouter } from 'vue-router';
import { _ as _export_sfc } from '../server.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-devtools-stub';
import 'axios';
import 'vue3-lazyload';

const _sfc_main$1 = {
  __name: "Carousel",
  __ssrInlineRender: true,
  props: {
    list: {
      type: Array,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    ref(breakpoints.greater("md"));
    useRouter();
    const carouselRef = ref();
    let isCarouselHover = useElementHover(carouselRef);
    const currentVisibleImg = ref(0);
    const addImgIndex = () => {
      if (currentVisibleImg.value >= props.list.length - 1) {
        currentVisibleImg.value = 0;
      } else {
        currentVisibleImg.value++;
      }
    };
    const { pause, resume } = useIntervalFn(() => {
      addImgIndex();
    }, 4e3);
    watch(isCarouselHover, (value) => {
      if (!value) {
        resume();
      } else {
        pause();
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: "mx-auto rounded-lg",
        ref_key: "carouselRef",
        ref: carouselRef
      }, _attrs))} data-v-7288abfa><div class="relative" data-v-7288abfa><div class="overflow-hidden relative h-[440px] ph:h-64 rounded-lg bg-black" data-v-7288abfa><!--[-->`);
      ssrRenderList(props.list, (item, index2) => {
        _push(`<div class="${ssrRenderClass(`duration-700 ease-in-out ${currentVisibleImg.value === index2 ? "" : "hidden"}`)}" data-v-7288abfa><span class="absolute top-1/2 left-1/2 text-2xl font-semibold text-white -translate-x-1/2 -translate-y-1/2 sm:text-3xl dark:text-gray-800" data-v-7288abfa></span><img${ssrRenderAttr("src", unref(util).replaceImgPath(item.metaInfo.focusPic))} class="min-h-[460px] ph:min-h-[255px] block absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 object-cover" alt="" data-v-7288abfa><div class="whitespace-normal text-center ph:text-sm flex p-1 absolute bottom-0 left-1/2 z-30 space-x-3 -translate-x-1/2 bg-black w-full min-h-11 max-h-10 opacityLinear text-2xl text-white justify-center items-center rounded-b-lg" data-v-7288abfa>${ssrInterpolate(item.title)}</div></div>`);
      });
      _push(`<!--]--></div><div class="flex absolute bottom-10 left-1/2 z-30 space-x-3 -translate-x-1/2" data-v-7288abfa><!--[-->`);
      ssrRenderList(props.list, (item, index2) => {
        _push(`<button type="button" class="${ssrRenderClass(`w-3 h-3 rounded-full ${index2 === currentVisibleImg.value ? "bg-white" : "bg-slate-600"}`)}" data-v-7288abfa></button>`);
      });
      _push(`<!--]--></div><div class="flex absolute top-0 left-0 z-0 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-v-7288abfa><span class="inline-flex justify-center items-center w-8 h-8 rounded-full bg-white/50 dark:bg-gray-800/30 group-hover:bg-white/90 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none" data-v-7288abfa><svg class="w-5 h-5 text-gray-800 sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-v-7288abfa><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" data-v-7288abfa></path></svg><span class="hidden" data-v-7288abfa>Previous</span></span></div><div class="flex absolute top-0 right-0 z-0 justify-center items-center px-4 h-full cursor-pointer group focus:outline-none" data-v-7288abfa><span class="inline-flex justify-center items-center w-8 h-8 rounded-full bg-white/50 dark:bg-gray-800/30 group-hover:bg-white/90 dark:group-hover:bg-gray-800/60 group-focus:ring-4 group-focus:ring-white dark:group-focus:ring-gray-800/70 group-focus:outline-none" data-v-7288abfa><svg class="w-5 h-5 text-gray-800 sm:w-6 sm:h-6 dark:text-gray-800" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" data-v-7288abfa><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" data-v-7288abfa></path></svg><span class="hidden" data-v-7288abfa>Next</span></span></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ListItem/Carousel.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const Carousel = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-7288abfa"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const startRenderList = ref(false);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const bottomRef = ref();
    const tabRef = ref();
    const targetIsVisible = useElementVisibility(bottomRef);
    const tabIsVisible = useElementVisibility(tabRef);
    const Articlelist = ref([]);
    const testData = ref([]);
    const { query } = useRoute();
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("clearArticleList")), await __temp, __restore();
    const getArticleList = async () => {
      await channelStore.dispatch("getArticleList");
      Articlelist.value = [...channelStore.state.articleList.data];
      startRenderList.value = true;
    };
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannel", query.id)), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getChannelAdd", query.id)), await __temp, __restore();
    [__temp, __restore] = withAsyncContext(() => getArticleList()), await __temp, __restore();
    watch(() => channelStore.state.articleList.data, (value) => {
      Articlelist.value = [...value];
    });
    const carouselList = ref([]);
    watch(() => channelStore.state.currentChannelId, async (value) => {
      if (value && channelStore.state.channelList.data.length) {
        await getCarousel(value);
      }
    });
    [__temp, __restore] = withAsyncContext(() => channelStore.dispatch("getCarousel", 350)), await __temp, __restore();
    carouselList.value = [...channelStore.state.carouselList];
    const getCarousel = async (value) => {
      const { title } = channelStore.state.channelList.data.find((i) => i.id == value);
      if (title === "\u9996\u9875") {
        await channelStore.dispatch("getCarousel", value);
        nextTick(() => {
          carouselList.value = [...channelStore.state.carouselList];
        });
      }
      carouselList.value = [];
    };
    watch(targetIsVisible, (value) => {
      if (startRenderList.value && value && !channelStore.state.articleListOver) {
        channelStore.dispatch("addPage").then(() => {
          getArticleList();
        });
      }
    });
    const router = useRouter();
    const toDetail = (data) => {
      util.jump(data, router, isPc);
    };
    const onSearch = (text) => {
      const herf = router.resolve({
        path: "search",
        query: {
          keyword: text
        }
      });
      window.open(herf.href, "_blank");
    };
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_Head = Head;
      const _component_ClientOnly = __nuxt_component_1;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_Head, null, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<title data-v-e4b3e1dd${_scopeId}>${ssrInterpolate("\u65B0\u5FEB\u7F51_\u65B0\u4E2D\u4EA7\u7684\u79FB\u52A8\u8D44\u8BAF\u53CB\u4F34")}</title>`);
          } else {
            return [
              createVNode("title", null, toDisplayString("\u65B0\u5FEB\u7F51_\u65B0\u4E2D\u4EA7\u7684\u79FB\u52A8\u8D44\u8BAF\u53CB\u4F34"))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<!--[-->`);
      ssrRenderList([testData.value[0]], (item) => {
        _push(`<div data-v-e4b3e1dd><div data-v-e4b3e1dd>${ssrInterpolate(item)}</div></div>`);
      });
      _push(`<!--]-->`);
      if (!unref(tabIsVisible) && isPc.value) {
        _push(`<div class="w-full flex fixed top-0 bg-white h-20 items-center shadow-md z-50 justify-center" data-v-e4b3e1dd><div class="w-[1500px] flex" data-v-e4b3e1dd><div class="w-3/4 flex items-center justify-between" data-v-e4b3e1dd><img class="m-2 h-12"${ssrRenderAttr("src", _imports_0$2)} alt="\u65B0\u5FEB\u7F51logo" data-v-e4b3e1dd>`);
        _push(ssrRenderComponent(CustomTabs, {
          ref_key: "tabRef",
          ref: tabRef,
          class: "justify-around",
          isPc: isPc.value
        }, null, _parent));
        _push(`</div><div class="w-1/4 mx-2" data-v-e4b3e1dd>`);
        _push(ssrRenderComponent(SearchBar, { onOnSearch: onSearch }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex flex-col items-center" data-v-e4b3e1dd><div class="w-full h-[320px] flex items-center flex-col bg-no-repeat bg-cover bg-searchBarBackground ph:bg-none ph:h-fit relative" data-v-e4b3e1dd><div class="mask" data-v-e4b3e1dd></div><div class="text-lg text-white flex justify-end py-2 pr-6 w-full cursor-pointer ph:hidden absolute ph:relative" data-v-e4b3e1dd>`);
      _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
      _push(`</div><div class="w-full h-full flex-1 flex items-center absolute ph:relative" data-v-e4b3e1dd><div class="h-16 w-full ph:h-14 ph:px-2 flex justify-center ph:justify-between ph:items-center ph:bg-primary flex-col items-center ph:flex-row" data-v-e4b3e1dd><img class="hidden ph:flex ph:h-8"${ssrRenderAttr("src", _imports_1)} alt="" data-v-e4b3e1dd>`);
      _push(ssrRenderComponent(SearchBar, {
        onOnSearch: onSearch,
        class: "w-1/2 ph:w-[250px]"
      }, null, _parent));
      if (isPc.value) {
        _push(`<div class="w-1/2" data-v-e4b3e1dd><!--[-->`);
        ssrRenderList(unref(channelStore).state.recommendList, (item) => {
          _push(`<div class="mr-4 flex items-center cursor-pointer" data-v-e4b3e1dd><img${ssrRenderAttr("src", _imports_2)} class="h-3 w-3" data-v-e4b3e1dd><div class="text-white" data-v-e4b3e1dd>${ssrInterpolate(item.title)}</div></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div><div class="w-[1100px] flex ph:w-full justify-center mt-5 ph:mt-3" data-v-e4b3e1dd><div class="w-9/12 ph:w-full ph:px-2 mr-6 ph:mr-0" data-v-e4b3e1dd>`);
      _push(ssrRenderComponent(CustomTabs, {
        ref_key: "tabRef",
        ref: tabRef,
        class: "mb-8 ph:mb-4 ph:pb-2 ph:border-b-[1px] ph:border-gray-300",
        isPc: isPc.value
      }, null, _parent));
      if (unref(channelStore).state.currentChannelId === "350" && !isPc.value) {
        _push(`<div data-v-e4b3e1dd><!--[-->`);
        ssrRenderList(unref(channelStore).state.recommendList, (item) => {
          _push(`<div class="mr-4 flex items-center cursor-pointer" data-v-e4b3e1dd><img${ssrRenderAttr("src", _imports_2)} class="h-3 w-3" data-v-e4b3e1dd><div class="container" data-v-e4b3e1dd><span class="${ssrRenderClass(`${item.title.length > 20 ? "scroll-text" : ""}`)}" data-v-e4b3e1dd>${ssrInterpolate(item.title)}</span></div></div>`);
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      if (Articlelist.value.length) {
        _push(`<div class="w-full" data-v-e4b3e1dd>`);
        if ((_a = carouselList.value) == null ? void 0 : _a.length) {
          _push(ssrRenderComponent(Carousel, {
            list: carouselList.value,
            class: "mb-3"
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`<!--[-->`);
        ssrRenderList(Articlelist.value, (item) => {
          _push(ssrRenderComponent(ListItem, {
            data: item,
            key: item,
            onClick: ($event) => toDetail(item)
          }, null, _parent));
        });
        _push(`<!--]--></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="w-3/12 ph:hidden pl-2" data-v-e4b3e1dd>`);
      _push(ssrRenderComponent(SideBar, null, null, _parent));
      _push(`</div></div>`);
      if (!unref(tabIsVisible)) {
        _push(ssrRenderComponent(ScrollToTop, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full" data-v-e4b3e1dd>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/home/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-e4b3e1dd"]]);

export { index as default };
//# sourceMappingURL=index-b8f6c69a.mjs.map
