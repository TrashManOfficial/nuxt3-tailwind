const StrongTitle_vue_vue_type_style_index_0_scoped_b2a4c4b5_lang = '.isActiveTab[data-v-b2a4c4b5]{background-color:#11a4af;border-radius:10px;height:11px;margin-top:-11px;opacity:.6;transform:rotateX(180deg);width:100%}.isActiveTab[data-v-b2a4c4b5]:after{background-color:#d94f14;border-radius:10px;content:"";display:block;height:2px;margin:0 auto;width:50%}';

const StrongTitleStyles_5e582e59 = [StrongTitle_vue_vue_type_style_index_0_scoped_b2a4c4b5_lang];

export { StrongTitleStyles_5e582e59 as default };
//# sourceMappingURL=StrongTitle-styles.5e582e59.mjs.map
