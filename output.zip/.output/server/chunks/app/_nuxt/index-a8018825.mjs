import { ref, watch, unref, useSSRContext, computed, mergeProps, withCtx, createVNode, toDisplayString } from 'vue';
import { ssrRenderClass, ssrRenderAttr, ssrRenderComponent, ssrInterpolate, ssrRenderList, ssrRenderAttrs } from 'vue/server-renderer';
import { a as useBreakpoints, f as breakpointsTailwind, u as useElementVisibility, c as channelStore, _ as _imports_0$2, C as CustomTabs, L as ListItem, d as SideBar, e as ScrollToTop, F as Footer, b as util, S as StrongTitle, D as DropDownList } from './ScrollToTop-504779c7.mjs';
import { useRoute, useRouter } from 'vue-router';
import { _ as _export_sfc } from '../server.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'h3';
import 'devalue';
import '../../nitro/node-server.mjs';
import 'node-fetch-native/polyfill';
import 'node:http';
import 'node:https';
import 'destr';
import 'ofetch';
import 'unenv/runtime/fetch/index';
import 'hookable';
import 'scule';
import 'klona';
import 'defu';
import 'ohash';
import 'ufo';
import 'unstorage';
import 'radix3';
import 'node:fs';
import 'node:url';
import 'pathe';
import '@heroicons/vue/24/solid';
import 'unctx';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-devtools-stub';
import 'axios';
import 'vue3-lazyload';

const DEFAULT_KEY = "showmore";
const _sfc_main$1 = {
  __name: "CustomTabsSpecial",
  __ssrInlineRender: true,
  props: {
    data: Array,
    isPc: Boolean
  },
  setup(__props) {
    const props = __props;
    useRouter();
    const tabList = ref([]);
    watch(() => props.data, (value) => {
      var _a, _b, _c, _d;
      if (value.metaInfo) {
        tabList.value = (_b = (_a = value.metaInfo) == null ? void 0 : _a.specialDoc) == null ? void 0 : _b.groups.map((i) => {
          return {
            id: i.groupId,
            name: i.name
          };
        });
        if ((_d = (_c = value.metaInfo) == null ? void 0 : _c.specialDoc) == null ? void 0 : _d.groups) {
          setCurrentId(tabList.value[0].id);
        } else {
          setCurrentId(value.metaInfo.groupId);
        }
      }
    });
    const DEFAULT_LENGTH = computed(() => {
      return props.isPc ? 6 : tabList.value.length;
    });
    const currentId = ref("");
    const setCurrentId = (id) => {
      currentId.value = id;
      channelStore.dispatch("setCurrentGroupId", id).then(() => {
        channelStore.dispatch("getSpecialList");
      });
    };
    const showList = computed(() => {
      return [...tabList.value.slice(0, DEFAULT_LENGTH.value), { id: DEFAULT_KEY, name: "\u66F4\u591A" }];
    });
    const hiddenList = computed(() => {
      if (tabList.value.length < DEFAULT_LENGTH.value) {
        return [];
      }
      return tabList.value.slice(DEFAULT_LENGTH.value);
    });
    const hiddenListClick = (data) => {
      channelStore.dispatch("exchangeItem", { index: DEFAULT_LENGTH.value, data });
      setCurrentId(data.id);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full flex ph:overflow-x-auto justify-start" }, _attrs))}><!--[-->`);
      ssrRenderList(showList.value, (item) => {
        _push(`<div class="flex justify-start">`);
        if (item.id !== DEFAULT_KEY) {
          _push(ssrRenderComponent(StrongTitle, {
            class: "mr-4",
            name: item.name,
            isCurrent: currentId.value === item.id,
            onClick: ($event) => setCurrentId(item.id)
          }, null, _parent));
        } else if (hiddenList.value.length) {
          _push(`<div class="w-fit cursor-pointer">`);
          _push(ssrRenderComponent(DropDownList, {
            list: hiddenList.value,
            onItemClick: hiddenListClick
          }, {
            default: withCtx((_, _push2, _parent2, _scopeId) => {
              if (_push2) {
                _push2(`<div class="font-trsFontFace text-2xl px-1 break-keep font-light"${_scopeId}>${ssrInterpolate(item.name)}</div>`);
              } else {
                return [
                  createVNode("div", { class: "font-trsFontFace text-2xl px-1 break-keep font-light" }, toDisplayString(item.name), 1)
                ];
              }
            }),
            _: 2
          }, _parent));
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]-->`);
      if (!__props.isPc) {
        _push(`<div class="flex-1"><div class="${ssrRenderClass(`font-trsFontFace text-2xl px-1 break-keep`)}"> \u66F4\u591A </div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CustomTabsSpecial.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const CustomTabsSpecial = _sfc_main$1;
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { query } = useRoute();
    const router = useRouter();
    const startRenderList = ref(false);
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isPc = ref(breakpoints.greater("md"));
    const bottomRef = ref();
    const tabRef = ref();
    useElementVisibility(bottomRef);
    const tabIsVisible = useElementVisibility(tabRef);
    const imgUrl = ref("");
    const Articlelist = ref([]);
    const ArticleDetail = ref({});
    const getSpecialDetail = () => {
      channelStore.dispatch("getArticleDetails", query.docid).then(() => {
        ArticleDetail.value = channelStore.state.articleDetail;
        imgUrl.value = util.replaceImgPath(channelStore.state.articleDetail.metaInfo.thumbnails[0]);
        channelStore.dispatch("setCurrentDocId", query.docid).then(() => {
          startRenderList.value = true;
        });
      });
    };
    const getChannels = async () => {
      await channelStore.dispatch("getChannel");
      await channelStore.dispatch("getChannelAdd");
      getSpecialDetail();
    };
    getChannels();
    watch(() => channelStore.state.articleList.data, (value) => {
      Articlelist.value = [...value];
    });
    const toDetail = (data) => {
      util.jump(data, router, isPc);
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<!--[-->`);
      if (isPc.value) {
        _push(`<div class="${ssrRenderClass(`w-full flex bg-white h-20 items-center shadow-md z-50 justify-center ${unref(tabIsVisible) ? "" : "fixed top-0"}`)}" data-v-406ecc5a><div class="w-[1500px] flex items-center justify-between" data-v-406ecc5a><img class="m-2 h-12"${ssrRenderAttr("src", _imports_0$2)} data-v-406ecc5a>`);
        _push(ssrRenderComponent(CustomTabs, {
          class: "justify-around",
          isPc: isPc.value
        }, null, _parent));
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div data-v-406ecc5a></div><div class="flex flex-col items-center" data-v-406ecc5a><div class="w-[1100px] h-full flex flex-col items-center p-12 ph:bg-none ph:h-fit opacityLinear" data-v-406ecc5a><div class="w-full shadow-xl rounded-2xl" data-v-406ecc5a><img class="w-full rounded-2xl"${ssrRenderAttr("src", imgUrl.value)} alt="" data-v-406ecc5a><div class="text-3xl p-8 flex justify-between items-center" data-v-406ecc5a><div data-v-406ecc5a>${ssrInterpolate(ArticleDetail.value.title)}</div></div></div></div><div class="w-[1100px] flex ph:w-full justify-center mt-3" data-v-406ecc5a><div class="w-9/12 ph:w-full mr-6" data-v-406ecc5a>`);
      _push(ssrRenderComponent(CustomTabsSpecial, {
        ref_key: "tabRef",
        ref: tabRef,
        class: "mb-8",
        isPc: isPc.value,
        data: ArticleDetail.value
      }, null, _parent));
      _push(`<div class="w-full" data-v-406ecc5a><!--[-->`);
      ssrRenderList(Articlelist.value, (item) => {
        _push(ssrRenderComponent(ListItem, {
          plainData: item,
          key: item,
          onClick: ($event) => toDetail(item)
        }, null, _parent));
      });
      _push(`<!--]--></div></div><div class="w-3/12 ph:hidden pl-2" data-v-406ecc5a>`);
      _push(ssrRenderComponent(SideBar, null, null, _parent));
      _push(`</div></div>`);
      if (!unref(tabIsVisible)) {
        _push(ssrRenderComponent(ScrollToTop, null, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="w-full" data-v-406ecc5a>`);
      _push(ssrRenderComponent(Footer, null, null, _parent));
      _push(`</div></div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/special/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-406ecc5a"]]);

export { index as default };
//# sourceMappingURL=index-a8018825.mjs.map
