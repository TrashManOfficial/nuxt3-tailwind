const index_vue_vue_type_style_index_0_scoped_e4b3e1dd_lang = ".mask[data-v-e4b3e1dd]{background:linear-gradient(180deg,transparent,rgba(3,47,50,.9));height:100%;opacity:1;position:absolute;width:100%}.container[data-v-e4b3e1dd]{overflow:hidden;white-space:nowrap;width:340px}.scroll-text[data-v-e4b3e1dd]{animation:scroll-e4b3e1dd 12s linear infinite;display:inline-block}@keyframes scroll-e4b3e1dd{0%{transform:translateX(20px)}to{transform:translateX(-100%)}}";

const indexStyles_54a394a4 = [index_vue_vue_type_style_index_0_scoped_e4b3e1dd_lang];

export { indexStyles_54a394a4 as default };
//# sourceMappingURL=index-styles.54a394a4.mjs.map
