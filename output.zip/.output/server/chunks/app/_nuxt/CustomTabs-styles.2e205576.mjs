const CustomTabs_vue_vue_type_style_index_0_scoped_f2103c1e_lang = ".scrollBar[data-v-f2103c1e]::-webkit-scrollbar{background-color:transparent;height:0;width:0}";

const CustomTabsStyles_2e205576 = [CustomTabs_vue_vue_type_style_index_0_scoped_f2103c1e_lang];

export { CustomTabsStyles_2e205576 as default };
//# sourceMappingURL=CustomTabs-styles.2e205576.mjs.map
