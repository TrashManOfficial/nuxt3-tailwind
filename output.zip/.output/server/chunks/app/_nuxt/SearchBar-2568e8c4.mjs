import { b as buildAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, ref, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';

const _imports_0 = "" + buildAssetsURL("search.d2616e1f.png");
const _sfc_main = {
  __name: "SearchBar",
  __ssrInlineRender: true,
  props: {
    data: String
  },
  emits: ["onSearch", "delete"],
  setup(__props, { emit }) {
    const props = __props;
    const text = ref(props.data);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mt-2 mb-2 border-2 pl-4 flex justify-between rounded-3xl bg-white" }, _attrs))}><input class="flex-grow outline-none text-gray-600 focus:text-primary" type="text" placeholder="\u8F93\u5165\u5173\u952E\u8BCD\u641C\u7D22"${ssrRenderAttr("value", text.value)}><img class="h-12 w-12 ph:h-9 ph:w-9 cursor-pointer active:scale-75"${ssrRenderAttr("src", _imports_0)} alt="\u641C\u7D22"></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SearchBar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const SearchBar = _sfc_main;

export { SearchBar as S };
//# sourceMappingURL=SearchBar-2568e8c4.mjs.map
