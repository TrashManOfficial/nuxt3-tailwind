const interopDefault = r => r.default || r || [];
const styles = {
  "pages/home/index.vue": () => import('./_nuxt/index-styles.b78ee429.mjs').then(interopDefault),
  "components/ListItem/Carousel.vue": () => import('./_nuxt/Carousel-styles.6b7eebb2.mjs').then(interopDefault),
  "components/CustomTabs.vue": () => import('./_nuxt/CustomTabs-styles.2e205576.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.a5c3f351.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.6b5b5ff2.mjs').then(interopDefault),
  "components/StrongTitle.vue": () => import('./_nuxt/StrongTitle-styles.5e582e59.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
