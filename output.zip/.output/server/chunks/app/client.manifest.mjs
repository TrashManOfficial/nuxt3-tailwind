const client_manifest = {
  "assets/images/ios.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "ios.93d30a48.png",
    "src": "assets/images/ios.png"
  },
  "assets/images/logo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo.65bd217b.png",
    "src": "assets/images/logo.png"
  },
  "assets/images/logo_m.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "logo_m.9890f935.png",
    "src": "assets/images/logo_m.png"
  },
  "assets/images/miniLogo.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "miniLogo.ebb38594.png",
    "src": "assets/images/miniLogo.png"
  },
  "assets/images/search.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "search.d2616e1f.png",
    "src": "assets/images/search.png"
  },
  "assets/images/searchBg.jpg": {
    "resourceType": "image",
    "mimeType": "image/jpeg",
    "file": "searchBg.18e7c232.jpg",
    "src": "assets/images/searchBg.jpg"
  },
  "assets/images/ygaba.png": {
    "resourceType": "image",
    "mimeType": "image/png",
    "file": "ygaba.5c590e6b.png",
    "src": "assets/images/ygaba.png"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "file": "error-404.23f2309d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-404.41034bc3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.23f2309d.css": {
    "file": "error-404.23f2309d.css",
    "resourceType": "style"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "file": "error-500.aa16ed4d.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "css": [],
    "file": "error-500.a1edf337.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.aa16ed4d.css": {
    "file": "error-500.aa16ed4d.css",
    "resourceType": "style"
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "file": "entry.66ba336a.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "searchBg.18e7c232.jpg"
    ],
    "css": [
      "entry.66ba336a.css"
    ],
    "dynamicImports": [
      "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs"
    ],
    "file": "entry.3409534e.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js"
  },
  "entry.66ba336a.css": {
    "file": "entry.66ba336a.css",
    "resourceType": "style"
  },
  "searchBg.18e7c232.jpg": {
    "file": "searchBg.18e7c232.jpg",
    "resourceType": "image",
    "mimeType": "image/jpeg"
  },
  "pages/home/index.css": {
    "resourceType": "style",
    "file": "index.97e0b6fa.css",
    "src": "pages/home/index.css"
  },
  "pages/home/index.vue": {
    "resourceType": "script",
    "module": true,
    "assets": [
      "logo.65bd217b.png",
      "logo_m.9890f935.png",
      "miniLogo.ebb38594.png",
      "search.d2616e1f.png",
      "ygaba.5c590e6b.png",
      "ios.93d30a48.png"
    ],
    "css": [],
    "file": "index.4df7eda0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/home/index.vue"
  },
  "index.97e0b6fa.css": {
    "file": "index.97e0b6fa.css",
    "resourceType": "style"
  },
  "logo.65bd217b.png": {
    "file": "logo.65bd217b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "logo_m.9890f935.png": {
    "file": "logo_m.9890f935.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "miniLogo.ebb38594.png": {
    "file": "miniLogo.ebb38594.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "search.d2616e1f.png": {
    "file": "search.d2616e1f.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "ygaba.5c590e6b.png": {
    "file": "ygaba.5c590e6b.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "ios.93d30a48.png": {
    "file": "ios.93d30a48.png",
    "resourceType": "image",
    "mimeType": "image/png"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "file": "index.e96a2781.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs": {
    "resourceType": "script",
    "module": true,
    "dynamicImports": [
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "error-component.b794c0df.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "virtual:nuxt:C:/Users/25784_hnuuivi/Desktop/project/test/nuxt/.nuxt/error-component.mjs"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
